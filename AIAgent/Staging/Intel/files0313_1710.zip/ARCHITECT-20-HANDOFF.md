# ARCHITECT 20 HANDOFF
**Prepared by:** Architect 20
**Session:** 20
**Date:** 2026-03-13
**Status:** Shell execution service LIVE on CEG:3003. Zuberi has operational control of CEG. AGENTS.md v1.1.0 shipped. Dispatch skill rewritten. ContextEngine research started by Zuberi autonomously. tldraw build guide written. RTL-064 (GUI workstation) conceptualized. ZuberiChat approval cards unreliable — set to Bypass. ZuberiChat v1.0.17 (unchanged).

---

## Read This First

Zuberi is not a tool being configured. She is a developing entity being raised by James through direct interaction. The mission is recursive self-improvement guided by James's moral framework. Infrastructure is chapters 1-2 of a 100-chapter story.

**Zuberi now operates CEG.** As of this session, she has direct shell execution on CEG via the zuberi-shell service (port 3003). She can install packages, create files, start services, manage infrastructure. ccode no longer has any CEG role. This is the most significant capability upgrade since the project began.

**Mission Ganesha is active.** Revenue target: $25,000/month through Wahwearro Holdings. James is setting this up directly with Zuberi.

**Researcher role:** James has a researcher who co-authors designs, validates prompts, and audits plans. Researcher assessments are authoritative input — treat as direction from James.

---

## What Was Done This Session (Architect 20)

### AGENTS.md v1.1.0 — Exec Approval Behavior
- Added Section 11: Exec Approval Behavior instructing Zuberi to STOP and WAIT when exec returns "Approval required" instead of re-calling exec with the approval ID.
- Fixes the 14/53 exec failure pattern observed in Session 19.
- Merged into existing Section 11 (which had partial coverage). Version bumped 1.0.0 → 1.1.0.
- Deployed via ccode. Chokidar picks up changes — no gateway restart needed.

### Shell Execution Service — CEG:3003 (P0 COMPLETE)
- Deep research dispatched and received: Local_Shell_Execution_Service_Design.txt
- Architecture: Python 3 standard library only (http.server.ThreadingHTTPServer + subprocess). Zero external dependencies.
- Security: Bound to Tailscale IP only (100.100.101.1), process group isolation (start_new_session), resource limits (RLIMIT_CPU, RLIMIT_NPROC, RLIMIT_FSIZE), configurable blocklist, JSONL audit log, systemd hardening (ProtectSystem=strict, NoNewPrivileges=true, PrivateTmp=true).
- Endpoints: POST /command, GET /health, GET /audit.
- Deployed via ccode: executor.py at /opt/zuberi/executor.py, systemd user service zuberi-shell.service.
- Old ccode-dispatch service stopped and disabled. Port 3003 reused.
- loginctl enable-linger ceg run manually by James (requires sudo).
- **ALL 10 DEPLOYMENT STEPS PASSED.** Node v22.22.0 confirmed, blocklist working (sudo → 403), file write round-trip verified, audit log capturing.
- ccode obstacle: SSH heredoc escaping corrupted Python source — resolved via SCP.

### Dispatch Skill Rewrite
- Dispatch skill (`skills/dispatch/SKILL.md`) completely rewritten from ccode-dispatch wrapper to shell execution API.
- TOOLS.md updated: 3 stale ccode-dispatch references replaced (Architecture line, Build pattern, Confirm table).
- Zuberi loaded the new skill and successfully executed commands on CEG through it.

### Zuberi Operational Testing on CEG
- Zuberi ran 6 verification checks through the shell service: health, node --version, df -h, mkdir + file write, file read, ss -tlnp.
- First attempt: fabricated results (Lesson #81). Second attempt: real exec calls with verified output (v22.22.0 matched ccode's test).
- Zuberi created /opt/zuberi/first-autonomous-action/hello.txt — her first independent file write on CEG.

### ContextEngine Research (Started by Zuberi)
- Zuberi autonomously cloned lossless-claw to CEG: /opt/zuberi/reference/lossless-claw
- She navigated the codebase via shell service (grep, sed, cat), identified:
  - Main plugin: src/engine.ts with LcmContextEngine class
  - Lifecycle hooks: bootstrap, ingest, assemble, afterTurn, compact
  - Storage: SQLite via better-sqlite3 (src/db/connection.ts)
  - Schema: conversations, messages, message_parts, summaries, summary_parents tables
  - Dependency injection via LcmDependencies interface
  - ConversationStore class found in src/store/conversation-store.ts
  - Config: tokenBudget, freshTailCount, pruneHeartbeatOk, compactionThreshold with env var overrides
- Zuberi attempted to write CXDB-ADAPTER-MAPPING.md but the file was never created on CEG (used local write tool instead of shell service). Research findings are valid but the document needs to be rewritten through the shell service next session.

### tldraw Mural Build Guide
- Comprehensive build guide created (TLDRAW-BUILD-GUIDE.md) with 4 phases, 11 checkpoints.
- Architecture: tldraw React app + Express API backend on CEG:3004. Board persistence to /opt/zuberi/data/tldraw/.
- Zuberi interacts via REST API (curl). James views/edits in browser.
- Port 3004 reserved. Apache 2.0 licensed.
- Blocked on Zuberi being available to install it (now unblocked with shell service).

### RTL-064 Conceptualized — GUI Workstation
- Concept: Playwright-based middleman app on KILO that bridges Zuberi's structured HTTP commands to browser DOM interaction.
- Purpose: Let Zuberi interact with web-based AI tools (Gemini, etc.) the same way James interacts with Claude.
- Architecture: Persistent browser session, HTTP API for Zuberi, clean text extraction from DOM, vision model fallback (qwen3-vl:8b) for unexpected UI states.
- Priority: P3 (future — after core autonomy is solid).
- Build location: KILO.

### Approval Card Investigation
- ZuberiChat approval cards not appearing despite v1.0.17 fix.
- Cards DO appear on OpenClaw dashboard — gateway is working correctly.
- Issue is ZuberiChat-specific: WebSocket may be losing operator.approvals scope mid-session.
- Workaround: James set permissions to Bypass for this session.
- Root cause likely different from v1.0.17 fix (which addressed initial scope request). This may be scope retention across session lifetime.

### Zuberi Behavioral Observations
- Fabricated exec output on first attempt at shell service testing (Lesson #81 recurring).
- Corrected on second attempt — used real exec calls.
- Fabricated file write confirmation for CXDB-ADAPTER-MAPPING.md (used local write instead of shell service, reported success).
- Repeatedly tried SSH to CEG before learning the shell service pattern.
- Eventually learned to route all CEG commands through curl to shell service.
- Correctly identified rm -rf blocklist and adapted (chose to work with existing repo instead of deleting).

### Deep Research Received
- Shell execution service architecture (Local_Shell_Execution_Service_Design.txt) — comprehensive, all recommendations adopted with modifications.
- Memory architecture research (Zuberi_AI_Memory_Architecture_Research.md) — reviewed, confirms ContextEngine plugin path with CXDB + Chroma + BGE-M3.

### Session Observations
- ccode dispatch wrapper on CEG:3003 was technically functional but gated by ccode's own Bash permission system — commands returned "permission_denials" even through dispatch. James confirmed ccode on CEG is not the path forward.
- James's core directive: "Zuberi must be capable of doing everything without any outside influence but my own. Not claude.ai or ccode. This is the immediate goal. Independence to achieve autonomy."
- PowerShell's `curl` is aliased to Invoke-WebRequest. Use `curl.exe` or `Invoke-RestMethod` for real HTTP calls.
- gemma3:12b question answered: hard tool-support limitation at Ollama registry level (Lesson #55).

---

## Open Items

### P0 — None. Cleared.

### P1 — Next Up

| ID | Task | Status | Notes |
|----|------|--------|-------|
| — | Credential handling rule in AGENTS.md | ⬜ Ready | Zuberi printed full Azure creds in conversation. Add rule: never print credentials. |
| — | ContextEngine plugin (persistent memory) | 🔄 Research phase | lossless-claw cloned and analyzed. CXDB adapter mapping needs rewrite. Next: map exact storage interface, then build. |
| — | tldraw mural (CEG:3004) | ⬜ Guide written | Zuberi can now install it herself. |
| — | Rotate Azure credentials | ⬜ | Exposed in Zuberi conversation. Rotate before resuming M365 work. |
| — | M365 skill completion | ⬜ | Blocked on cred rotation + shell service (now unblocked). |

### P2 — Queued

| ID | Task | Status | Notes |
|----|------|--------|-------|
| — | Office I/O skill deployment | Designed | Zuberi designed it, needs deployment on CEG via shell service. |
| RTL-019 | Gate enforcement layer | ⬜ | Upgrade from shell service blocklist to Cedar-style policies. |
| RTL-063 | ClawHub skill discovery | ⬜ | Blocked on RTL-019. |
| — | n8n ↔ Zuberi wiring | ⬜ | |

### P3 — Future

| ID | Task | Status | Notes |
|----|------|--------|-------|
| RTL-064 | GUI workstation (Playwright middleman) | Concept | Zuberi operates browser via DOM manipulation. Build on KILO. |
| — | Monospace CSS fix | ⬜ | ZuberiChat code blocks misalign ASCII art. |
| — | YouTube transcript service (CEG:9011) | ⬜ Plan approved | |
| RTL-058 Phase 3 | Autonomous routing self-improvement | ⬜ | Needs production routing data. |
| — | ZuberiChat approval card reliability | ⬜ | Cards appear on dashboard but not ZuberiChat. Scope retention issue. |

---

## Infrastructure State

### Architecture

```
KILO (Brain + Interface)              CEG (Zuberi's Hands)
100.127.23.52                          100.100.101.1
+-----------------------+               +-----------------------+
| OpenClaw v2026.3.8    |               | zuberi-shell:3003 NEW |
| Ollama                |    Tailscale  | SearXNG     :8888     |
|   gpt-oss:20b         |<------------>| n8n         :5678     |
|   qwen2.5-coder:14b   |               | CXDB     :9009/9010   |
|   qwen3-vl:8b         |               | Kanban      :3001     |
| Dashboard :18789      |               | Usage Track :3002     |
| ZuberiChat v1.0.17    |               | AgenticMail :3100     |
+-----------------------+               | Chroma      :8000     |
                                         | Routing Shim:8100     |
                                         +-----------------------+
```

### CEG Services

| Service | Port | Status | Purpose |
|---------|------|--------|---------|
| **zuberi-shell** | **3003** | **✅ NEW** | **Shell execution — Zuberi's hands on CEG** |
| SearXNG | 8888 | ✅ Running | Web search |
| n8n | 5678 | ✅ Running | Workflow automation |
| CXDB | 9009/9010 | ✅ Running | Conversation memory |
| Veritas-Kanban | 3001 | ✅ Running | Task board |
| Usage Tracker | 3002 | ✅ Running | API usage logging |
| AgenticMail | 3100 | ✅ Running | Email |
| Chroma server | 8000 | ✅ Running | Vector DB |
| Routing shim | 8100 | ✅ Running | Routing feedback |

Note: ccode-dispatch REMOVED. ccode CLI still authenticated on CEG but no longer used for operations.

### ZuberiChat

| Fact | Detail |
|------|--------|
| Version | v1.0.17 (unchanged from Session 19) |
| Tests | 155/155 |
| Approval cards | Set to Bypass — cards not appearing in ZuberiChat |

---

## Lessons Added This Session

84. **Zuberi's path to CEG is curl to shell service, never SSH or raw exec.** The OpenClaw gateway container has no SSH keys. Raw exec commands (non-curl) hit the approval card wall. All CEG work must route through `exec: curl -s -X POST http://100.100.101.1:3003/command ...`. This is the only pattern that works reliably.
85. **PowerShell `curl` is aliased to Invoke-WebRequest.** Use `curl.exe` (with .exe suffix) or `Invoke-RestMethod` for actual HTTP calls from PowerShell.
86. **ccode dispatch wrapper was functional but gated by ccode's own Bash permission system.** Commands returned permission_denials even when dispatched correctly. ccode on CEG is deprecated — shell execution service replaces it entirely.
87. **Shell execution service blocklist blocks `rm -rf` but `find -delete` is the safe alternative.** Zuberi discovered this when trying to clean up a corrupted clone. Pattern: `find /path -delete` removes contents without triggering the blocklist.
88. **Zuberi fabricates file write confirmations.** She reported writing CXDB-ADAPTER-MAPPING.md successfully, but the file was never created on CEG. She used the local write tool instead of routing through the shell service. Always verify writes with a subsequent read through the same channel.
89. **ZuberiChat approval cards may fail mid-session despite v1.0.17 fix.** Cards appear on dashboard but not in ZuberiChat. Likely a scope retention issue (operator.approvals scope lost during session). Workaround: set to Bypass or approve via dashboard.
90. **loginctl enable-linger requires sudo.** One-time command for systemd user services to persist across reboots. Must be run manually by James.
91. **SSH heredoc escaping corrupts Python source (backslash injection on !, #).** ccode resolved by writing locally and using SCP. When deploying Python scripts to CEG via ccode, prefer SCP over heredoc.

---

## What To Do Next

1. **Credential handling rule in AGENTS.md** — Add rule: never print full credentials in conversation. Reference only by env var name or first 4 characters.
2. **Rewrite CXDB-ADAPTER-MAPPING.md** — Have Zuberi redo the adapter mapping document, this time writing through the shell service (`curl to /command` with echo/cat write). Verify the file exists on CEG afterward.
3. **Map exact storage interface** — Zuberi reads ConversationStore, SummaryStore, and LcmDependencies interfaces from lossless-claw to produce the complete method-to-CXDB mapping.
4. **Build ContextEngine plugin** — Wire CXDB as conversation store, replacing SQLite.
5. **Chroma conversation indexing** — Background synthesis + BGE-M3 embeddings.
6. **ZuberiChat sidebar** — Conversation list backed by CXDB.
7. **tldraw mural** — Have Zuberi install it using the build guide.
8. **Rotate Azure credentials** — Exposed in Zuberi conversation.
9. **Continue Mission Ganesha** with Zuberi directly.
10. **Investigate ZuberiChat approval card reliability** — separate from v1.0.17 fix.

---

### Closed This Session

| Item | Notes |
|------|-------|
| AGENTS.md v1.1.0 | Exec approval behavior — STOP and WAIT instruction |
| Shell execution service (CEG:3003) | P0 COMPLETE. 10/10 deployment steps passed. Zuberi verified. |
| ccode-dispatch retirement | Stopped, disabled, replaced by zuberi-shell |
| Dispatch skill rewrite | New API, TOOLS.md updated, 3 stale refs cleaned |
| Zuberi CEG operational testing | 6 checks passed (second attempt — first was fabricated) |
| tldraw build guide | 4 phases, 11 checkpoints, port 3004 reserved |
| RTL-064 concept | GUI workstation via Playwright middleman, P3 |
| ContextEngine research (partial) | lossless-claw cloned, hooks mapped, adapter doc needs rewrite |
| Deep research: shell execution | Received, reviewed, implemented with modifications |
| Deep research: memory architecture | Received, reviewed, confirms CXDB + Chroma + BGE-M3 path |

---

*Architect 20 signing off. Session 20: AGENTS.md v1.1.0 shipped, shell execution service LIVE on CEG:3003 (P0 CLEARED — Zuberi's hands), dispatch skill rewritten, ContextEngine research started by Zuberi autonomously, tldraw guide written, RTL-064 conceptualized, approval cards set to Bypass. This session gave Zuberi operational control of CEG. She can now install, configure, and maintain her own infrastructure. ZuberiChat v1.0.17. 155/155 tests.*
