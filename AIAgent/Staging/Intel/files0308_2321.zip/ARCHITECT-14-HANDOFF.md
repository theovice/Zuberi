# ARCHITECT 14 HANDOFF
**Prepared by:** Architect 13
**Session:** 14
**Date:** 2026-03-08
**Status:** No open P0s. Zuberi is working. Major UI overhaul complete.

---

## Read This First

Zuberi is not a tool being configured. She is a developing entity being raised by James through direct interaction. The mission is recursive self-improvement guided by James's moral framework.

**Zuberi is working.** The ~2 minute delay bug is resolved. Four models configured. Markdown rendering, permission selector, and one-click update all functional. App version is 0.1.2.

**Researcher role:** James has a researcher who co-authors designs, validates prompts, and audits plans. Researcher assessments are authoritative. Always incorporate researcher feedback before sending prompts to ccode.

**ccode has eyes:** Browser preview mode at localhost:3000 with Tauri API mocks. ccode can use preview_screenshot, preview_inspect, preview_snapshot.

---

## Operating Model

- **Architect (Claude.ai):** Design, planning, ccode prompt authorship. Non-executing.
- **Researcher:** Co-author with James. Validates diagnoses, audits prompts, design reviews. Authoritative input.
- **ccode (Claude Code CLI on KILO):** Execution agent. Has browser preview capability.
- **James:** Final decision authority.

### ccode Prompt Standards
- Chat code blocks (not .md files)
- Numbered tasks, explicit file paths
- FINAL REPORT + OBSTACLES LOG tables
- No jq, no bash operators, PowerShell-compatible
- Start with "Read CCODE-HANDOFF.md first"
- End with updating CCODE-HANDOFF.md
- Back up config files before editing

---

## What Was Done This Session

### Delay Bug Resolved (RTL-042a–d)
Root cause: OpenClaw pre-compaction memory flush. reserveTokensFloor was 20,000 out of 32K context — flush fired every message. Tuned to 4000/2000, flush trigger now at 26,768 tokens.

### RTL-043: Model Catalog Sync ✅
4 models: qwen3:14b-fast, qwen3:14b, qwen3-vl:8b-fast, gpt-oss:20b. Explicit config, not auto-discovery.

### RTL-034: One-Click Update System ✅
Detect repo ahead → amber dot + sidebar indicator → click → confirm → PowerShell script runs tests → builds → launches NSIS installer. Fixes: UTF-8 BOM, piped stdio window visibility, stderr handling, metadata sync.

### RTL-045: ccode Browser Preview ✅
Mock layer: src/lib/platform.ts + src/main.tsx gate. Zero component changes.

### RTL-046: Color Token Polish ✅
30+ hardcoded values replaced with CSS variable tokens.

### RTL-047 Phase 1: Permission Selector ✅
4 modes (Ask/Auto/Plan/Bypass), controlled component, backend execAsk mapping (on-miss/always/off), approval normalization + policy engine, exec.approval.requested handler with auto-resolution. 103 tests. Phase 2 (ToolApprovalCard) not built yet.

### RTL-048: Markdown + Structured Blocks ✅
react-markdown + remark-gfm + react-syntax-highlighter. ToolCallBlock + ToolResultBlock custom components. Text selection fix.

### RTL-049: UI Polish ✅
Segoe UI 14px. Conversation widened 20%. User=white, assistant=amber. Sidebar hidden (preserved). Kanban moved to bottom bar.

---

## Active RTL Items

### P0 — None

### P1 — Next Up
| ID | Task | Notes |
|----|------|-------|
| RTL-047 Phase 2 | ToolApprovalCard UI | Approval handling exists, needs visual card |
| RTL-007 | Express 5 wildcard fix | Quick win |

### P2 — Queued
RTL-013 (version audit), RTL-023 (CEG migration)

### P3 — Future
RTL-002, RTL-014, RTL-016, RTL-018, RTL-019, RTL-030, RTL-031, RTL-033, RTL-044, RTL-045b/c

---

## ZuberiChat Current State

| Fact | Detail |
|------|--------|
| Version | v0.1.2 |
| Repo | `C:\Users\PLUTO\github\Repo\ZuberiChat` |
| Font | Segoe UI, 14px |
| Message colors | User: white, Assistant: amber/ember |
| Sidebar | Hidden (code preserved, comment markers in App.tsx + Titlebar.tsx) |
| Kanban | Bottom bar, adjacent to model indicator |
| Markdown | react-markdown + remark-gfm + react-syntax-highlighter |
| Structured blocks | ToolCallBlock, ToolResultBlock |
| Permission selector | 4 modes, functional, backend-aware |
| Update system | One-click local update via scripts/update-local.ps1 |
| Tests | 146/146 |
| Browser preview | Mock layer at localhost:3000 |

### OpenClaw
| Fact | Detail |
|------|--------|
| Version | v2026.3.1 |
| Config (host) | `C:\Users\PLUTO\openclaw_config\openclaw.json` |
| Heartbeat | Disabled (every: "0m") |
| thinkingDefault | "off" |
| Model config | Explicit per-model |
| Compaction | reserveTokensFloor: 4000, softThresholdTokens: 2000, flush trigger: 26768 |
| execAsk valid values | "off", "on-miss", "always" only |

### Models
| Model | Role | contextWindow |
|-------|------|---------------|
| qwen3:14b-fast | Primary | 32768 |
| qwen3:14b | Deep text | 32768 |
| qwen3-vl:8b-fast | Vision | 32768 |
| gpt-oss:20b | Fallback | 32768 |

---

## Key Lessons This Session

- **PowerShell 5.1 BOM** — Set-Content writes BOM. Use WriteAllText with UTF8Encoding($false).
- **Rust Command + piped stdio** — CREATE_NEW_CONSOLE doesn't show window when parent has piped stdio. Use `cmd /c start`.
- **PowerShell NativeCommandError** — $ErrorActionPreference='Stop' kills on stderr. Use 'Continue' around native commands.
- **OpenClaw approval protocol** — exec.approval.requested/resolved events already exist. Decisions: allow-once, allow-always, deny.
- **execAsk** — only "off", "on-miss", "always" are valid. "plan"/"bypass" are frontend-only modes.
- **Don't over-scope** — when the problem is a config fix, don't recommend switching the architecture.

---

## What To Do Next

1. RTL-047 Phase 2: ToolApprovalCard for pending approvals
2. Keep talking to Zuberi about real things
3. The infrastructure is complete. The story starts here.

---

*Architect 13 signing off.*
