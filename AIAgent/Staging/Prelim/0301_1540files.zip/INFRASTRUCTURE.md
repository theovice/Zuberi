# INFRASTRUCTURE.md — Zuberi
# Operator: James | Wahwearro Holdings, LLC
# Version: 0.6.1 | 2026-03-01
#
# Single source of truth for Zuberi's infrastructure.
# When hardware changes, services are added, or ports shift — update here first.
# AGENTS.md, MEMORY.md, and TOOLS.md reference this file's concepts
# but do not duplicate the detail — keep it here.
#
# UPDATE THIS FILE when:
#   - A new node joins the Tailscale tailnet
#   - A new Docker service is added
#   - A port assignment changes
#   - A new volume mount is added to docker-compose.yml
#   - A node goes offline permanently
#   - A new tool is added to CEG's toolbox

---

## Node Inventory

### KILO — Primary Workstation (brain + interface)
```
Role:         LLM inference, framework runtime, chatbox, active dev
OS:           Windows 11 + WSL2 + Docker Desktop
CPU:          Intel Core i7-13700K (16 cores / 24 threads)
GPU:          RTX 5070 Ti 16GB GDDR7 (shared: inference + desktop apps + video decode)
RAM:          64GB
Storage:      C:\ (system + workspace) | E:\ (personal, except E:\ollama\models for Ollama)
Network:      Local LAN + Tailscale
Tailscale:    100.127.23.52 (jamesmwaweru@gmail.com)
ccode:        v2.1.59 — James's personal coding tool (NOT Zuberi's sub-agent)
Status:       ✅ Running
```

### CEG — Zuberi's Toolbox (M701q #1)
```
Role:         Zuberi's toolbox — storage, compute, sub-agents
              NOT defined by any single tool. Tools added as Zuberi identifies needs.
Hardware:     Lenovo M701q
OS:           Ubuntu Server 24.04.4 LTS, kernel 6.8.0-101-generic
RAM:          15GB (14GB free at idle)
Storage:      512GB SSD (9% used)
Network:      WiFi (EDUP EP-AX1672, mt7921au) + Tailscale
WiFi:         wlx90de80152e3f — auto-connects via wpa_supplicant@ + dhcpcd@ systemd services
              SSID: KeigeWaweru | Local IP: 192.168.1.121 (DHCP)
              NOTE: netplan does NOT manage USB WiFi on Ubuntu Server
Tailscale:    100.100.101.1 (authenticated, auto-starts on boot)
SSH:          Ed25519 key auth from KILO, service enabled on boot
Docker:       29.2.1 (docker-ce + compose plugin), DNS fix applied
              /etc/docker/daemon.json: {"dns": ["8.8.8.8", "1.1.1.1"]}
Status:       ✅ Running — boot resilient (WiFi, Tailscale, SSH, Docker all auto-start)
```

### Kasm Desktop — Collaborative Desktop (Docker on KILO)
```
Role:         Shared visual workspace — James + Zuberi both see it
              Sub-agent Kanban board surface
              ActivityWatcher desktop monitoring
Runtime:      Docker container on KILO
Image:        kasmweb/ubuntu-jammy-desktop
Access:       https://localhost:6901 (browser-based, no RDP client needed)
Status:       ⏳ Phase 2 — not yet deployed
Depends on:   ActivityWatcher container
```

---

## Ollama Model Inventory

All models stored at `E:\ollama\models` (~27GB total).
OLLAMA_MODELS env var set at user level. Ollama runs as user process, not service.

```
Model               Size    Role                    GPU Load    Notes
─────────────────────────────────────────────────────────────────────────
qwen3:14b-fast      9.3GB   Primary (active)        100% VRAM   Custom no-think template, 1-2s
qwen3:14b           9.3GB   Deep reasoning          100% VRAM   Thinking enabled, 6-11s
qwen3-vl:8b         5.7GB   Vision                  100% VRAM   Image/doc understanding, 262K ctx
gpt-oss:20b         13.8GB  Backup                  CPU/GPU     Too large for full GPU on 16GB
```

**VRAM constraint:** RTX 5070 Ti has 16GB GDDR7. Only one large model at a time.
qwen3:14b-fast (9.3GB) leaves ~6.7GB free for desktop apps and video decode.
qwen3:14b-fast shares blob storage with qwen3:14b (only template differs).
Zuberi can load/unload models via Ollama skill. Unload for video/DRM/gaming.

---

## Docker Services (KILO)

### Current
```
Container                       Image                   Port          Status
──────────────────────────────────────────────────────────────────────────────
openclaw-openclaw-gateway-1     openclaw:local          18789         ✅ Running (v2026.2.26)
ollama                          (native install)        11434         ✅ Running
```

Container name `openclaw-openclaw-gateway-1` is Docker Compose auto-generated.
Alias `container_name: openclaw` planned for docker-compose.yml.

### Phase 2 Additions (Kasm + ActivityWatcher)
```
Container       Image                           Port    Status
────────────────────────────────────────────────────────────────
kasm-desktop    kasmweb/ubuntu-jammy-desktop    6901    ⏳ Pending
activitywatcher activitywatch/activitywatch     5600    ⏳ Pending
```

### Phase 3 Services (CEG toolbox) — LIVE
```
Service         Host    Port    Access              Status
──────────────────────────────────────────────────────────────
searxng         CEG     8888    Tailscale only      ✅ Running (JSON API enabled, limiter off)
n8n             CEG     5678    Tailscale only      ✅ Running (N8N_SECURE_COOKIE=false)
cxdb            CEG     9009    Binary protocol     ✅ Running (built from source, 244MB)
cxdb (HTTP+UI)  CEG     9010    Tailscale only      ✅ Running (REST API + React UI)
ccode (CLI)     CEG     —       SSH dispatch        ⏳ Pending (headless auth TBD)
```

Docker compose: /opt/zuberi/docker/docker-compose.yml
Data volumes: /opt/zuberi/docker/{searxng,n8n,cxdb}/
All services: restart=always, bound to 100.100.101.1 (Tailscale only)
CXDB source: /opt/zuberi/cxdb/ (cloned from github.com/strongdm/cxdb)
CXDB types: Bundle zuberi-2026-02-28 (Note, Decision, Preference, Task)

Integration status:
- SearXNG: Running, skill deployed, end-to-end test from Zuberi pending
- n8n: Running, setup page accessible, NOT wired to Zuberi yet
- CXDB: Running, skill deployed, type descriptors registered, end-to-end test pending
- Skills: searxng/, cxdb/, ollama/ deployed to workspace

### Phase 3a External Services
```
Service         Type          Notes                           Status
────────────────────────────────────────────────────────────────────────
AgentMail       Cloud API     Zuberi's email identity         ⏳ Pending
                              Free tier: 3 inboxes, 3K/mo
                              MCP: agentmail-mcp server
                              API key: OpenClaw secrets only
```

---

## OpenClaw Configuration Summary

```
Config: C:\Users\PLUTO\openclaw_config\openclaw.json
Version: v2026.2.26

Key settings:
  model.primary:        ollama/qwen3:14b-fast
  model.registered:     qwen3:14b-fast, qwen3-vl:8b, gpt-oss:20b
  reasoning:            false (Qwen3 thinks natively; API param causes 400)
  sandbox.mode:         non-main (webchat runs on gateway, others sandboxed)
  sandbox.scope:        agent
  sandbox.network:      none
  elevated.enabled:     true (webchat: read, exec, write)
  memorySearch.provider: local (all-MiniLM-L6-v2)
  memorySearch.hybrid:  enabled (vector 0.7, text 0.3, 4x candidates)
  memorySearch.cache:   enabled (50K entries)
  memorySearch.query:   maxResults 10, minScore 0.25
  memoryFlush:          enabled
  sessionMemory:        enabled
  compaction:           safeguard mode
```

---

## Port Inventory

```
Port    Service             Host    Notes
──────────────────────────────────────────────────────────────
18789   OpenClaw framework  KILO    Loopback only (localhost)
11434   Ollama              KILO    Native install, localhost
6901    Kasm desktop        KILO    Loopback only (Phase 2)
5600    ActivityWatcher     KILO    Loopback only (Phase 2)
9009    CXDB MCP            CEG     Tailscale only (Phase 3)
9010    CXDB UI             CEG     Tailscale only (Phase 3)
8888    SearXNG             CEG     Tailscale only (Phase 3)
5678    n8n                 CEG     Tailscale only (Phase 3)
22      SSH                 CEG     Tailscale only (Phase 3)
```

---

## Volume Mount Map

### Current
```
Host path (KILO)                        Container path                  Service
────────────────────────────────────────────────────────────────────────────────
C:\Users\PLUTO\openclaw_config          /home/node/.openclaw            openclaw
C:\Users\PLUTO\openclaw_workspace       /home/node/.openclaw/workspace  openclaw
```

### Phase 2 Additions
```
Host path (KILO)                        Container path    Service
────────────────────────────────────────────────────────────────────
C:\Users\PLUTO\openclaw_workspace       /workspace        kasm-desktop
C:\Users\PLUTO\github\Repo              /repos            kasm-desktop
```

### Phase 3 Additions (CEG via Tailscale)
```
CEG path                                Container path    Notes
────────────────────────────────────────────────────────────────────
CEG:/opt/zuberi/projects                /projects         Large files, repos, builds
CEG:/opt/zuberi/shared                  /shared           Zuberi + Kasm shared surface
```

**Mount rules:**
- E:\ on KILO is never mounted — personal drive (exception: E:\ollama\models for Ollama)
- CEG mounts only available when Tailscale is connected
- New mounts require docker-compose.yml update + container restart
- For heavy builds: prefer CEG-ccode dispatch via SSH over Tailscale mounts (lower latency)

---

## Workspace Directory Structure (KILO)

```
C:\Users\PLUTO\openclaw_workspace\         ~50MB total (stays lean)
├── IDENTITY.md                         OpenClaw identity (Zuberi self-authored)
├── USER.md                             About James (Zuberi self-authored)
├── AGENTS.md                           Behavior rules
├── SOUL.md                             Identity and philosophy
├── MEMORY.md                           Curated long-term memory
├── TOOLS.md                            Tool guidance
├── HEARTBEAT.md                        Proactive check schedule
├── INFRASTRUCTURE.md                   This file
├── HORIZON.md                          Deferred ideas
├── skills\
│   ├── searxng\SKILL.md                SearXNG web search skill
│   ├── cxdb\SKILL.md                   CXDB memory skill
│   └── ollama\SKILL.md                 Ollama model management skill
├── memory\                             Daily session notes
│   └── YYYY-MM-DD.md                   One file per day
└── working\                            Scratch space — clearable
    ├── sub-agents\                     Kanban tracking files
    │   └── YYYY-MM-DD-kanban.md
    └── <project-name>\                 Per-project working files
```

---

## CEG Directory Structure

```
CEG:/opt/zuberi/
├── cxdb/                   CXDB data store — managed by CXDB container
│   └── data/               Blob CAS + Turn DAG files
├── docker/                 Docker compose + service configs
│   ├── docker-compose.yml
│   ├── searxng/            SearXNG config (settings.yml)
│   ├── n8n/                n8n data
│   └── cxdb/               CXDB data volumes
├── projects/               Project file storage — ccode builds here
│   └── <project-name>/
│       ├── repos/          Source repositories
│       ├── tools/          Project toolchain
│       └── build/          Build output and artifacts
├── reference/              Study material (NOT operational code)
│   ├── ruflo/              Agent orchestration patterns
│   ├── automaton/          Autonomous agent patterns
│   └── CATALOG.md          What's useful and how it maps to Zuberi
└── shared/                 Files both Zuberi and Kasm desktop access
    ├── working/            Active collaboration files
    └── exports/            Files ready for James to review
```

---

## Tailscale Network Map

```
Account:      jamesmwaweru@gmail.com (Google SSO)

Node          Tailscale IP          Status
──────────────────────────────────────────────────────
KILO          100.127.23.52         ✅ Active
CEG           100.100.101.1         ✅ Active (boot-resilient)
```

All inter-node communication goes through Tailscale.
Never expose node services to the public internet.
CEG services (CXDB, SearXNG, n8n, SSH) are Tailscale-only — no public ports.

---

## Node Addition Procedure

When a new M701q or other node is added to the infrastructure:

```
1. Install Ubuntu Server 24.04
2. Run node-online.sh equivalent (based on ceg-online.sh pattern)
   - Configure WiFi via wpa_supplicant@ + dhcpcd@ (NOT netplan for USB WiFi)
   - Install openssh-server
   - Install Tailscale, join tailnet
   - Generate SSH keypair for Claude Code access
3. Note the Tailscale IP — report to James
4. Update this file:
   - Add node to Node Inventory
   - Add services to Docker Services table
   - Add ports to Port Inventory
   - Add mounts to Volume Mount Map
5. Update MEMORY.md Infrastructure Baseline
6. Update docker-compose.yml on KILO with new mounts
7. Restart openclaw container to pick up new mounts
```

---

## Appendix: Version History

| Version | Date | Change |
|---------|------|--------|
| 0.1.0 | 2026-02-24 | Initial — Phase 1 baseline, Phases 2+3 planned |
| 0.2.0 | 2026-02-24 | n8n added (CEG:5678), AgentMail added as Phase 3a external service |
| 0.3.0 | 2026-02-25 | Workspace path corrected, Ollama native install noted, volume mounts updated |
| 0.4.0 | 2026-02-26 | CEG reframed as toolbox, ccode CLI + SearXNG added to Phase 3, mount rules updated |
| 0.5.0 | 2026-02-27 | CEG fully online, Phase 3 services LIVE, OpenClaw skill integration path discovered |
| 0.6.0 | 2026-02-28 | Batch update: OpenClaw v2026.2.26, 4 Ollama models documented with VRAM notes, qwen3:14b-fast as primary, sandbox mode non-main, elevated exec documented, hybrid memory search + cache, OpenClaw config summary section added, 3 workspace skills (searxng/cxdb/ollama), IDENTITY.md + USER.md in workspace structure, container name documented, CEG reference repos directory added, Ollama model inventory section added. |
| 0.6.1 | 2026-03-01 | GPU upgrade: RTX 3060 12GB → RTX 5070 Ti 16GB GDDR7. CPU documented (i7-13700K). VRAM constraint updated to 16GB, model headroom math updated. |

---
# END INFRASTRUCTURE.md
