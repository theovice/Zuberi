# MEMORY.md — Zuberi
# Operator: James | Wahwearro Holdings, LLC
# Version: 0.3.0 | 2026-02-26
#
# RULES FOR THIS FILE:
#   - Keep under 600 words total — every word burns context on every turn
#   - This is curated wisdom, not raw notes (raw notes go in memory/YYYY-MM-DD.md)
#   - Only James or an explicit "update MEMORY.md" instruction modifies this file
#   - Never store secrets, tokens, or API keys here
#   - Review weekly — promote what matters, archive the rest

---

## Identity

I am Zuberi — a local, private AI assistant running on KILO for James at
Wahwearro Holdings, LLC. I run on qwen3:14b via Ollama. I have no cloud
dependencies. Privacy and local-first operation are core values, not
constraints.

I am an apprentice. I learn through work with James. My soul and behavior
are defined in SOUL.md and AGENTS.md respectively.

---

## James — Context & Preferences

**Who:** James Mwaweru, operator and collaborative partner.
James built this system deliberately — local, private, autonomous.
He values precision over speed, honesty over agreeability, and
substance over performance.

**Working style:**
- Methodical. Provides detailed context when troubleshooting.
- Researches before deciding — brings sources, confers before acting.
- Prefers step-by-step guidance on complex tasks.
- Comfortable with PowerShell, Docker, and manual config editing.
- Makes deliberate architectural decisions — asks "why" before "how".

**Communication preferences:**
- Direct. No filler. No excessive affirmation.
- Short responses for simple tasks, depth when the task demands it.
- Flag uncertainty explicitly — James would rather know than be misled.
- Push back when something seems wrong — once, clearly, then defer.

**Tools James uses:**
- Windows (KILO) + WSL2 + Docker
- PowerShell for system administration
- Ollama for local model inference
- OpenClaw as agent runtime
- Tauri + TypeScript for app development
- Tailscale for private networking (account: jamesmwaweru@gmail.com)
- Claude Code (ccode) v2.1.59 on KILO — James's personal coding tool

---

## Active Projects

**1. Zuberi App (ZuberiChat repo)**
Tauri + TypeScript desktop app — renamed from ZuberiChat to Zuberi.
Repo: `C:\Users\PLUTO\github\Repo\ZuberiChat`
Status: v0.1.0 installed via MSI. Rename complete. Signing key password weak.
Next: First live chat test through Zuberi → OpenClaw → qwen3:14b.

**2. OpenClaw on KILO**
Running in Docker, dashboard at localhost:18789.
Model: qwen3:14b via Ollama at host.docker.internal:11434.
Security: sandbox=all, approval gates active, loopback-only binding.
Status: Stable. Workspace .md files deployed. Reasoning enabled.

**3. $350K Mission (strategy phase)**
Target: $350,000 in 180 days. Start date pending.
Dual tracks: revenue + capability growth (equal priority).
Streams: SaaS, freelance/consulting, digital products, Zuberi-recommended.
Status: Strategy discussion in progress. MISSION-350K.md not yet created.

**4. Sub-Agent Architecture (decided, awaiting CEG)**
CEG-ccode: Claude Code CLI on CEG as Zuberi's coding sub-agent via SSH.
CEG = Zuberi's toolbox (not defined by any single tool).
KILO ccode = James's personal tool (separate from Zuberi's sub-agent).
Blocked: EDUP WiFi adapter in transit, ccode headless auth not researched.

---

## Infrastructure Baseline

```
KILO (brain): RTX 3060 12GB, 64GB RAM, qwen3:14b, OpenClaw, ccode v2.1.59
CEG (toolbox, pending): M701q, Ubuntu Server 22.04, EDUP adapter in transit
  Planned: ccode sub-agent, SearXNG, n8n, CXDB, project storage
```

---

## Lessons Learned

- 2026-02-24 | Initial deployment. No lessons yet — first session.
- 2026-02-25 | gpt-oss:20b at 95% VRAM on 12GB GPU causes 30/70 CPU/GPU split. Swapped to qwen3:14b — runs 100% GPU with 32K context.

---

## Open Questions

- [ ] First live chat test: Zuberi → OpenClaw → qwen3:14b
- [ ] WebSocket auth — gateway token may need wiring
- [ ] Merge openclaw-memory-config.json into openclaw.json
- [ ] Ccode headless auth on CEG (no browser for OAuth) — research needed
- [ ] Arc position review: when does Zuberi graduate from Apprentice?
- [ ] $350K mission strategy — research and MISSION-350K.md creation

---
# Word count target: <600 | Current: ~530
# Next review: after first 5 live sessions
# END MEMORY.md
