# INFRASTRUCTURE.md — Zuberi
# Operator: James | Wahwearro Holdings, LLC
# Version: 0.4.0 | 2026-02-26
#
# Single source of truth for Zuberi's infrastructure.
# When hardware changes, services are added, or ports shift — update here first.
# AGENTS.md, MEMORY.md, and TOOLS.md reference this file's concepts
# but do not duplicate the detail — keep it here.
#
# UPDATE THIS FILE when:
#   - A new node joins the Tailscale tailnet
#   - A new Docker service is added
#   - A port assignment changes
#   - A new volume mount is added to docker-compose.yml
#   - A node goes offline permanently
#   - A new tool is added to CEG's toolbox

---

## Node Inventory

### KILO — Primary Workstation (brain + interface)
```
Role:         LLM inference, framework runtime, chatbox, active dev
OS:           Windows 11 + WSL2 + Docker Desktop
CPU:          [KILO spec]
GPU:          RTX 3060 12GB
RAM:          64GB
Storage:      C:\ (system + workspace) | E:\ (personal — not Zuberi's domain)
Network:      Local LAN + Tailscale
Tailscale:    Installed, authenticated (jamesmwaweru@gmail.com)
ccode:        v2.1.59 — James's personal coding tool (NOT Zuberi's sub-agent)
Status:       ✅ Running
```

### CEG — Zuberi's Toolbox (M701q #1)
```
Role:         Zuberi's toolbox — storage, compute, sub-agents
              NOT defined by any single tool. Tools added as Zuberi identifies needs.
Hardware:     Lenovo M701q
OS:           Ubuntu Server 22.04, kernel 6.8.0-100-generic
RAM:          [CEG spec]
Storage:      512GB SSD
Network:      Tailscale (pending WiFi adapter)
WiFi:         EDUP MT7921AU (Amazon B0CZ82RM5L) — in transit
Tailscale:    Pending adapter arrival
SSH:          Will be configured via ceg-online.sh
Status:       ⏳ Pending — WiFi adapter in transit
Next:         Run ceg-online.sh → Tailscale → tool deployment
```

### Kasm Desktop — Collaborative Desktop (Docker on KILO)
```
Role:         Shared visual workspace — James + Zuberi both see it
              Sub-agent Kanban board surface
              ActivityWatcher desktop monitoring
Runtime:      Docker container on KILO
Image:        kasmweb/ubuntu-jammy-desktop
Access:       https://localhost:6901 (browser-based, no RDP client needed)
Status:       ⏳ Phase 2 — not yet deployed
Depends on:   ActivityWatcher container
```

---

## Docker Services (KILO)

### Current (Phase 1)
```
Container       Image                   Port          Status
─────────────────────────────────────────────────────────────
openclaw        openclaw/openclaw       18789         ✅ Running
ollama          (native install)        11434         ✅ Running
```

### Phase 2 Additions (Kasm + ActivityWatcher)
```
Container       Image                           Port    Status
────────────────────────────────────────────────────────────────
kasm-desktop    kasmweb/ubuntu-jammy-desktop    6901    ⏳ Pending
activitywatcher activitywatch/activitywatch     5600    ⏳ Pending
```

### Phase 3 Additions (CEG toolbox)
```
Service         Host    Port    Access              Status
──────────────────────────────────────────────────────────────
ccode (CLI)     CEG     —       SSH dispatch        ⏳ Pending (auth TBD)
cxdb            CEG     9009    MCP endpoint        ⏳ Pending
cxdb-ui         CEG     9010    Browser UI          ⏳ Pending
searxng         CEG     8888    Tailscale only      ⏳ Pending
n8n             CEG     5678    Tailscale only      ⏳ Pending
```

Note: CEG tools are added incrementally as Zuberi identifies needs and
James approves. The list above reflects currently planned tools, not a
fixed manifest.

### Phase 3a External Services
```
Service         Type          Notes                           Status
────────────────────────────────────────────────────────────────────────
AgentMail       Cloud API     Zuberi's email identity         ⏳ Pending
                              Free tier: 3 inboxes, 3K/mo
                              MCP: agentmail-mcp server
                              API key: OpenClaw secrets only
```

**AgentMail notes:**
- Purpose: Zuberi's dedicated email identity, separate from James's Gmail
- Integration: agentmail-mcp → registered in OpenClaw as MCP tool
- OpenClaw docs: agentmail.to/blog/agentmail-vs-gmail-openclaw
- Privacy caveat: cloud-hosted, email transits AgentMail infrastructure
- Long-term: self-hosted alternative tracked in HORIZON.md Section 1
- API key: OpenClaw secrets config only — never in any .md file

---

## Port Inventory

```
Port    Service             Host    Notes
──────────────────────────────────────────────────────────────
18789   OpenClaw framework  KILO    Loopback only (localhost)
11434   Ollama              KILO    Native install, localhost
6901    Kasm desktop        KILO    Loopback only (Phase 2)
5600    ActivityWatcher     KILO    Loopback only (Phase 2)
9009    CXDB MCP            CEG     Tailscale only (Phase 3)
9010    CXDB UI             CEG     Tailscale only (Phase 3)
8888    SearXNG             CEG     Tailscale only (Phase 3)
5678    n8n                 CEG     Tailscale only (Phase 3)
22      SSH                 CEG     Tailscale only (Phase 3)
```

---

## Volume Mount Map

### Current (Phase 1)
```
Host path (KILO)                        Container path    Service
────────────────────────────────────────────────────────────────────
C:\Users\PLUTO\openclaw_config          /home/node/.openclaw   openclaw
C:\Users\PLUTO\openclaw_workspace       /home/node/.openclaw/workspace   openclaw
```

### Phase 2 Additions
```
Host path (KILO)                        Container path    Service
────────────────────────────────────────────────────────────────────
C:\Users\PLUTO\openclaw_workspace       /workspace        kasm-desktop
C:\Users\PLUTO\github\Repo              /repos            kasm-desktop
```

### Phase 3 Additions (CEG via Tailscale)
```
CEG path                                Container path    Notes
────────────────────────────────────────────────────────────────────
CEG:/opt/zuberi/projects                /projects         Large files, repos, builds
CEG:/opt/zuberi/shared                  /shared           Zuberi + Kasm shared surface
```

**Mount rules:**
- E:\ on KILO is never mounted — personal drive
- CEG mounts only available when Tailscale is connected
- New mounts require docker-compose.yml update + container restart
- For heavy builds: prefer CEG-ccode dispatch via SSH over Tailscale mounts (lower latency)

---

## CEG Directory Structure

```
CEG:/opt/zuberi/
├── cxdb/                   CXDB data store — managed by CXDB container
│   └── data/               Blob CAS + Turn DAG files
├── projects/               Project file storage — ccode builds here
│   └── <project-name>/
│       ├── repos/          Source repositories
│       ├── tools/          Project toolchain
│       └── build/          Build output and artifacts
└── shared/                 Files both Zuberi and Kasm desktop access
    ├── working/            Active collaboration files
    └── exports/            Files ready for James to review
```

---

## Tailscale Network Map

```
Account:      jamesmwaweru@gmail.com (Google SSO)
Tailnet:      [tailnet name — update when CEG joins]

Node          Tailscale IP          Status
──────────────────────────────────────────────────────
KILO          100.127.23.XXX        ✅ Active
CEG           <pending>             ⏳ Pending adapter
```

All inter-node communication goes through Tailscale.
Never expose node services to the public internet.
CEG services (CXDB, SearXNG, n8n, SSH) are Tailscale-only — no public ports.

---

## Workspace Directory Structure (KILO)

```
C:\Users\PLUTO\openclaw_workspace\         ~50MB total (stays lean)
├── AGENTS.md                           Behavior rules
├── SOUL.md                             Identity and philosophy
├── MEMORY.md                           Curated long-term memory
├── TOOLS.md                            Tool guidance
├── HEARTBEAT.md                        Proactive check schedule
├── INFRASTRUCTURE.md                   This file
├── HORIZON.md                          Deferred ideas
├── memory\                             Daily session notes
│   └── YYYY-MM-DD.md                   One file per day
└── working\                            Scratch space — clearable
    ├── sub-agents\                     Kanban tracking files
    │   └── YYYY-MM-DD-kanban.md
    └── <project-name>\                 Per-project working files
        ├── research-notes.md
        ├── architecture-plan.md
        └── build-log.md
```

---

## Node Addition Procedure

When a new M701q or other node is added to the infrastructure:

```
1. Install Ubuntu Server 22.04
2. Run node-online.sh equivalent (based on ceg-online.sh pattern)
   - Configure WiFi/network
   - Install openssh-server
   - Install Tailscale, join tailnet
   - Generate SSH keypair for Claude Code access
3. Note the Tailscale IP — report to James
4. Update this file:
   - Add node to Node Inventory
   - Add services to Docker Services table
   - Add ports to Port Inventory
   - Add mounts to Volume Mount Map
5. Update MEMORY.md Infrastructure Baseline
6. Update docker-compose.yml on KILO with new mounts
7. Restart openclaw container to pick up new mounts
```

---

## Appendix: Version History

| Version | Date | Change |
|---------|------|--------|
| 0.1.0 | 2026-02-24 | Initial — Phase 1 baseline, Phases 2+3 planned |
| 0.2.0 | 2026-02-24 | n8n added (CEG:5678), AgentMail added as Phase 3a external service |
| 0.3.0 | 2026-02-25 | Workspace path corrected to openclaw_workspace, Ollama noted as native install, volume mounts updated to match actual docker-compose |
| 0.4.0 | 2026-02-26 | CEG reframed as "Zuberi's toolbox" throughout (not defined by any single tool). Added ccode CLI and SearXNG to Phase 3 services. Added ccode v2.1.59 to KILO (James's personal tool, separate from CEG ccode). Added SearXNG port 8888 to port inventory. Updated mount rules (prefer SSH dispatch for heavy builds). Updated CEG directory note (ccode builds here). |

---
# END INFRASTRUCTURE.md
