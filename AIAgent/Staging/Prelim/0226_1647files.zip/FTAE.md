# FTAE.md — Future Task / Autonomy Execution
# Operator: James Mwaweru | Wahwearro Holdings, LLC
# Version: 0.4.0 | 2026-02-26
#
# PURPOSE: Maps what Zuberi can and cannot do autonomously, organized by
# capability and task type. Defines the execution path any project follows,
# identifies what gates each stage, and lays out the unlock sequence with
# concrete solutions for each gap.
#
# Lives alongside conversation-handoff.md. Updated by the Architect
# when capabilities change or new task categories are identified.
#
# Reference example: concert ticket resale SaaS (used to illustrate how
# stages and capabilities interact, but the framework applies to any project).

---

## 1. Maturity Scale

| Level | Symbol | Meaning |
|-------|--------|---------|
| Ready | ✅ | Zuberi can do this today |
| Partial | 🟡 | Can start but will hit limits or need human help |
| Blocked | ❌ | Missing capability or config prevents this |

---

## 2. Capability Inventory

| ID | Capability | Status | Has Today | Solution | Depends On |
|----|-----------|--------|-----------|----------|------------|
| C1 | Long-form writing & reasoning | ✅ | qwen3:14b, 32K ctx, thinking mode | — | — |
| C2 | File read/write | ✅ | OpenClaw tools: read, write, edit, apply_patch | — | — |
| C3 | Local code execution | ✅ | OpenClaw exec tool, sandbox mode=all | — | — |
| C4 | Web search | ❌ | Not configured | See §3.1 | Sandbox network or gateway-level search |
| C5 | Package install / build tools | ❌ | Sandbox network=none | See §3.2 | Sandbox network change or custom image |
| C6 | Multi-agent coordination | 🟡 | CEG-ccode architecture decided | See §3.8 | CEG online, ccode authenticated |
| C7 | Workflow automation (n8n) | ❌ | n8n not deployed | See §3.7 | CEG online |
| C8 | Structured data output (xlsx) | 🟡 | csv/json yes, xlsx no | See §3.5 | C5 (package install) |
| C9 | Database access | ❌ | No DB connected | See §3.6 | CEG online or local SQLite |
| C10 | Stronger reasoning model | 🟡 | qwen3:14b capable but capped | See §3.9 | GPU upgrade |
| C11 | Persistent memory | 🟡 | memoryFlush + memorySearch configured | See §3.10 | Testing + daily use |
| C12 | External API integrations | ❌ | No outbound API access | See §3.3 | Sandbox network + key management |
| C13 | Image/diagram generation | ❌ | No image model | See §3.11 | GPU headroom or CPU-based model |
| C14 | Browser interaction / scraping | ❌ | Browser tool denied | See §3.4 | Sandbox browser config |
| C15 | Document generation (pdf/docx) | 🟡 | Markdown/html only | See §3.5 | C5 (package install) |
| C16 | Coding sub-agent (ccode) | ❌ | Architecture decided, not deployed | See §3.12 | CEG online, ccode auth |

---

## 3. Solutions — Capability by Capability

### 3.1 Web Search (C4)

**The gap:** Zuberi can't search the web. Without this, Research and Legal/Compliance tasks are fully blocked, and Strategy tasks are limited to training data.

**Solution options (ranked by alignment with Zuberi's principles):**

**Option A: SearXNG (self-hosted, recommended)**
- Run SearXNG as a Docker container alongside OpenClaw
- Aggregates Google, Brave, DuckDuckGo, and 70+ engines
- Zero API keys, zero cost, fully local/private
- OpenClaw has a local-websearch skill and a pending PR for native SearXNG provider support
- Config: `docker run -d --name searxng --restart=always -p 8888:8080 searxng/searxng:latest`
- Wire to OpenClaw via `tools.web.search.provider: "searxng"` and `searxng.baseUrl: "http://searxng:8888"`
- Pair with `web_fetch` for full page content extraction
- Can run on KILO now (lightweight) or on CEG when online
- **Privacy: ✅ All queries stay local. No third-party sees search data.**

**Option B: Brave Search API (free tier)**
- 2,000 searches/month free, no credit card needed
- OpenClaw's default recommended provider
- Config: `tools.web.search.provider: "brave"` + API key
- Simple setup: `openclaw configure --section web`
- **Privacy: 🟡 Queries go to Brave's servers**

**Option C: Perplexity Sonar via OpenRouter**
- AI-synthesized answers with citations from real-time search
- Requires OpenRouter account (supports crypto/prepaid, no credit card)
- Returns richer context than raw search results
- **Privacy: 🟡 Queries go to OpenRouter + Perplexity**

**Recommendation:** Option A (SearXNG). Aligns with local-first, no API keys, no cost, no external dependencies. Can run on KILO immediately as a Docker container. When CEG comes online, move it there to free KILO resources.

**Sandbox note:** Web search via OpenClaw's gateway-level `web_search` tool does NOT require sandbox network changes. The search happens at the gateway level (host network), not inside the sandbox container. This means C4 can be unlocked without touching sandbox network policy.

---

### 3.2 Package Install / Build Tools (C5)

**The gap:** Sandbox containers run with `network: "none"`. Zuberi can't `npm install`, `pip install`, or `cargo add`. Code scaffolding and tool installation are blocked.

**Solution options:**

**Option A: Custom sandbox image (recommended)**
- Bake a custom Docker image with common toolchains pre-installed
- Include: Node.js, Python 3, pip, pnpm, git, curl, jq, openpyxl, reportlab, python-docx
- Build once, use forever. No network needed at runtime.
- Config: `agents.defaults.sandbox.docker.image: "zuberi-sandbox:latest"`
- Dockerfile lives in the Zuberi workspace or a dedicated repo
- Update the image when new tools are needed, rebuild, restart

**Option B: setupCommand with temporary egress**
- Set `sandbox.docker.network: "bridge"` (or a named network)
- Add `setupCommand: "apt-get update && apt-get install -y nodejs python3 python3-pip && pip install openpyxl reportlab python-docx"`
- setupCommand runs once per container creation, not every session
- Requires: `readOnlyRoot: false` and `user: "0:0"` (root)
- **Risk: Container has network access during setup.**

**Option C: Controlled egress via Docker network + proxy**
- Create a dedicated Docker network with a Squid proxy
- Allowlist specific domains (npmjs.org, pypi.org, github.com)
- Block everything else
- Most secure for ongoing network access, but more complex to set up

**Recommendation:** Option A (custom image) for Phase 1 of this capability. Pre-install everything Zuberi commonly needs. No runtime network required, no security tradeoff. If dynamic installs become a need later, layer Option C on top.

---

### 3.3 External API Integrations (C12)

**The gap:** Zuberi can't call external APIs (Stripe, Ticketmaster, GitHub API, etc.). Build and Automate stages are blocked for anything requiring external service interaction.

**Solution options:**

**Option A: Gateway-level API proxy (recommended)**
- OpenClaw's gateway runs on the host with full network access
- Build a custom tool or skill that proxies API calls through the gateway
- API keys stored in `.env` or `openclaw.json` (gateway side, not sandbox side)
- Zuberi requests "call Stripe API with X payload" → gateway executes → returns result
- Zuberi never sees raw API keys
- **Security: ✅ Keys never enter sandbox. Gateway controls access.**

**Option B: Sandbox env vars**
- Pass API keys via `sandbox.docker.env` config
- Requires sandbox network access (Option B or C from §3.2)
- Zuberi calls APIs directly from inside the sandbox
- **Security: 🟡 Keys are inside the sandbox. Model has access.**

**Option C: n8n as API middleware**
- Zuberi sends API requests to n8n via REST
- n8n handles auth, rate limiting, error handling
- Zuberi never touches raw credentials
- Requires: CEG online + n8n deployed
- **Security: ✅ Keys stay in n8n. Adds workflow layer.**

**Recommendation:** Option A for direct API calls, Option C for recurring or complex integrations. Both keep keys out of the sandbox. Option A is available sooner (just needs a custom skill). Option C adds workflow orchestration but requires CEG.

---

### 3.4 Browser Interaction / Scraping (C14)

**The gap:** Browser tool is denied in current config. Zuberi can't visit websites, interact with web UIs, or scrape dynamic content.

**Solution options:**

**Option A: OpenClaw sandboxed browser (recommended)**
- OpenClaw has built-in sandboxed browser support
- Runs a headless browser in a dedicated Docker container
- Config: enable `browser` in tool allowlist, configure `sandbox.browser`
- Auto-starts when needed, noVNC observer for James to watch
- `sandbox.browser.network` uses a dedicated Docker network (separate from exec sandbox)
- Can restrict via `allowedControlUrls` and `allowedControlHosts`
- **Security: ✅ Isolated container, observable, restrictable**

**Option B: Firecrawl CLI skill**
- Provides `firecrawl search`, `firecrawl scrape`, `firecrawl browser`
- Handles JS-heavy sites, bot protection, interactive automation
- Runs in a remote sandbox (Firecrawl's infrastructure) — no local Chromium
- Requires Firecrawl API key (free tier available)
- **Privacy: 🟡 Content goes through Firecrawl's servers**

**Recommendation:** Option A. Local, sandboxed, observable, aligns with privacy principles.

---

### 3.5 Structured Data Output + Document Generation (C8, C15)

**The gap:** Zuberi can write csv/json/markdown/html but can't produce xlsx, pdf, or docx files natively.

**Solution:** This is a dependency of C5 (package install). Once the custom sandbox image includes the right Python libraries, these capabilities unlock automatically.

**Libraries to bake into custom sandbox image:**
- `openpyxl` — xlsx creation and editing
- `reportlab` — pdf generation
- `python-docx` — docx creation and editing
- `matplotlib` — charts and graphs (for reports)
- `pandas` — data manipulation and csv/xlsx conversion

**No config change needed beyond C5.** Once the libraries exist in the image, Zuberi can use them via the exec tool.

---

### 3.6 Database Access (C9)

**The gap:** No persistent data store. Zuberi can't track state across sessions beyond memory/ files, and can't build app backends.

**Solution options:**

**Option A: SQLite on KILO (immediate, lightweight)**
- SQLite requires no server — just a file
- Zuberi can create and query `.db` files via Python's built-in `sqlite3`
- Store in workspace: `openclaw_workspace/data/zuberi.db`
- No new infrastructure needed. Works inside sandbox if file is bind-mounted.

**Option B: CXDB on CEG (planned, Phase 3)**
- Full database server on CEG
- Accessible from KILO via Tailscale
- Requires: CEG online + Docker + Tailscale

**Option C: PostgreSQL container on KILO (intermediate)**
- Run PostgreSQL as a Docker container alongside OpenClaw
- Accessible from sandbox via Docker networking
- More capable than SQLite, less infrastructure than CEG

**Recommendation:** Start with Option A (SQLite) immediately. Move to Option B (CXDB on CEG) when CEG comes online.

---

### 3.7 Workflow Automation — n8n (C7)

**The gap:** No workflow engine. Zuberi can't schedule jobs, monitor external data, or build automation pipelines.

**Solution:** n8n on CEG as one tool in CEG's toolbox (not the defining service).

**Implementation path:**
1. CEG comes online (EDUP adapter → Tailscale)
2. Deploy n8n as Docker container on CEG
3. Wire Zuberi ↔ n8n via REST API
4. Zuberi builds workflows by calling n8n's API (requires James approval to activate)
5. n8n executes workflows on schedule, reports back

**n8n is an automation layer, not an agent.** It doesn't plan or reason — it follows wired steps. Zuberi orchestrates; n8n executes recurring automated tasks.

---

### 3.8 Multi-Agent Coordination (C6)

**The gap:** Single agent. Complex tasks that span multiple domains run sequentially through one agent.

**Solution: CEG-ccode as first sub-agent (decided)**

Architecture:
```
ZUBERI (orchestrator, KILO)
  → dispatches coding tasks to CEG-ccode via SSH
  → parses JSON results
  → logs to sub-agent kanban
  → reports to James or chains next subtask

Dispatch pattern:
  ssh ceg "cd /opt/zuberi/projects/<project> && claude -p '<task>' --output-format json --max-turns 5"
```

**Key properties:**
- Ccode in headless mode (`-p`) is functionally an agent — it plans, uses tools, returns results
- CEG-ccode is Zuberi's hands. KILO ccode is James's personal tool. Separate.
- Ccode builds directly on CEG filesystem — no Tailscale mount latency
- Session chaining via `--session-id` for multi-step builds
- Tool scoping via `--allowedTools` per invocation

**Future multi-agent expansion:**
Once CEG-ccode is stable and mission execution is underway, additional
specialist agents may be added (research agent, data agent, etc.) based
on gaps Zuberi identifies via the capability growth system (AGENTS.md §9).

**Prerequisites:**
- CEG online (EDUP adapter → Tailscale)
- Ccode CLI installed and authenticated on CEG
- SSH key configured KILO → CEG
- Ccode headless auth solved (no browser for OAuth — research needed)

---

### 3.9 Stronger Reasoning Model (C10)

**The gap:** qwen3:14b is capable but limited on complex multi-step reasoning.

**Solution: Claude via ccode sub-agent (decided)**

The ccode sub-agent runs Claude (Sonnet/Opus) via Anthropic's API. This means
Zuberi already has access to stronger reasoning for coding tasks — just dispatched
to CEG-ccode rather than running locally.

For non-coding tasks requiring stronger reasoning, the options remain:
- **GPU upgrade** for larger local model (RTX 3090 → qwen3:32b)
- **Claude API remote agent** via ccode for specific complex tasks

This is partially resolved by the sub-agent architecture. Full resolution
requires either GPU upgrade or broader Claude API integration.

---

### 3.10 Persistent Memory (C11)

**The gap:** memoryFlush and memorySearch are configured but untested.

**Solution:** Testing and usage problem, not a config problem.

**Steps to validate:**
1. Multi-turn session where decisions are made
2. Observe: does Zuberi write to `memory/YYYY-MM-DD.md` at compaction?
3. New session — ask about something from previous session
4. Check: does memorySearch find relevant context?
5. If not working, diagnose gateway logs

**No infrastructure change needed.** Just real-world usage and observation.

---

### 3.11 Image/Diagram Generation (C13)

**The gap:** Zuberi can't generate images, charts, or visual assets.

**Solution:** Bake Mermaid CLI + Matplotlib into custom sandbox image (covers diagrams + charts). Defer local image generation model until GPU upgrade.

---

### 3.12 Coding Sub-Agent — CEG-Ccode (C16)

**The gap:** Zuberi can't delegate coding tasks. All code work runs through the main agent session, consuming context and blocking other tasks.

**Solution: Claude Code CLI on CEG (decided)**

**Implementation path:**
1. CEG comes online (EDUP adapter → Tailscale → SSH)
2. Install Claude Code CLI on CEG: `npm install -g @anthropic-ai/claude-code`
3. Authenticate ccode on CEG (headless auth — method TBD, see HORIZON.md §4)
4. Configure SSH key KILO → CEG for passwordless dispatch
5. Test: `ssh ceg "claude -p 'echo hello' --output-format json"`
6. Wire into Zuberi's dispatch pattern (TOOLS.md §Sub-Agent Tools)

**Blockers:**
- [ ] EDUP WiFi adapter arrives
- [ ] CEG joins tailnet
- [ ] Ccode headless auth method researched and tested
- [ ] SSH key pair configured

**Impact:** Zuberi can delegate code generation, scaffolding, bug fixes,
and build tasks. Frees main agent context for planning and coordination.
Directly supports $350K mission by enabling SaaS and product development.

---

## 4. Project Execution Path

Every project follows this sequence. Some stages are skipped depending on the task.

```
RESEARCH → STRATEGY → MODEL → DESIGN → BUILD → AUTOMATE
  C4,C14     C1,C11    C1,C3    C1,C2    C2,C3    C7,C9
                        C8,C5    C3       C5,C12   C12,C14
                                          C16
```

### Current Readiness by Stage

| Stage | Status | Blocker | Solution Priority |
|-------|--------|---------|-------------------|
| Research | ❌ Blocked | No web search (C4), no browser (C14) | §3.1 SearXNG — can unlock NOW |
| Strategy | ✅ Ready | Quality limited without research inputs | Improves automatically when C4 unlocks |
| Financial Model | 🟡 Partial | No xlsx output (C8), no tooling (C5) | §3.5 Custom sandbox image |
| Design | ✅ Ready | Diagram rendering is nice-to-have (C13) | §3.11 Mermaid CLI in sandbox image |
| Build | ❌ Blocked | No package install (C5), no APIs (C12), no sub-agent (C16) | §3.2 Custom image + §3.3 Gateway proxy + §3.12 CEG-ccode |
| Automate | ❌ Blocked | No n8n (C7), no DB (C9), no APIs (C12) | §3.7 n8n deploy + §3.6 SQLite interim |

---

## 5. Unlock Sequence

### Tier 0: Done (Phase 1) ████████████████████
**Capabilities:** C1, C2, C3, C11 (partial)
**Stages:** Strategy ✅, Design ✅

### Tier 1: Web Search — NO HARDWARE OR SANDBOX CHANGES NEEDED
**Capabilities unlocked:** C4 (web search)
**Stages improved:** Research → 🟡 Partial (search yes, browser not yet)

**What to do:**
1. Deploy SearXNG as Docker container on KILO
2. Add `tools.web.search` config to `openclaw.json` pointing to SearXNG
3. Add `web_fetch` to tool allowlist if not already present
4. Add `web_search` to tool allowlist (currently denied)
5. Restart OpenClaw gateway

**Trigger conditions:**
- [x] No hardware needed
- [x] No sandbox network change needed (search runs at gateway level)
- [ ] James approves adding web search capability

**Impact:** Research stage goes from ❌ to 🟡. Strategy quality improves significantly.

---

### Tier 2: Custom Sandbox Image — NO HARDWARE CHANGES NEEDED
**Capabilities unlocked:** C5 (package install), C8 (xlsx), C13 (diagrams/charts), C15 (pdf/docx)
**Stages improved:** Financial Model → ✅, Design → ✅ (with rendered diagrams)

**What to do:**
1. Create `Dockerfile.zuberi-sandbox` based on `openclaw-sandbox:bookworm-slim`
2. Install: Node.js, Python 3, pip, pnpm, git, curl, jq
3. Install Python libs: openpyxl, reportlab, python-docx, matplotlib, pandas
4. Install diagram tools: `mmdc` (mermaid CLI)
5. Build: `docker build -t zuberi-sandbox:latest -f Dockerfile.zuberi-sandbox .`
6. Update `openclaw.json`: `agents.defaults.sandbox.docker.image: "zuberi-sandbox:latest"`
7. Restart OpenClaw gateway

**Trigger conditions:**
- [x] No hardware needed
- [x] No sandbox network change at runtime (everything pre-installed)
- [ ] James approves custom image approach

**Impact:** Financial Model and Document Generation go from 🟡 to ✅.

---

### Tier 3: Browser + Database — MINOR CONFIG CHANGES
**Capabilities unlocked:** C14 (browser), C9 (database via SQLite)
**Stages improved:** Research → ✅, Build → 🟡 (can prototype with SQLite)

**What to do (browser):**
1. Build sandbox browser image: `scripts/sandbox-browser-setup.sh`
2. Add `browser` to tool allowlist in `openclaw.json`
3. Configure `sandbox.browser` with allowlists for approved domains
4. Test with a harmless site first

**What to do (database):**
1. Create SQLite database in workspace: `openclaw_workspace/data/zuberi.db`
2. Bind-mount into sandbox container via sandbox config
3. Zuberi uses Python `sqlite3` module (already in standard library)

**Trigger conditions:**
- [ ] James approves browser tool enablement
- [ ] James defines domain allowlist for browser access
- [ ] James approves SQLite as interim database

**Impact:** Research fully unlocked. Prototyping database-backed apps becomes possible.

---

### Tier 4: External API Access — REQUIRES NETWORK DECISION
**Capabilities unlocked:** C12 (external APIs)
**Stages improved:** Build → ✅ (full stack with API integrations)

**What to do:**
1. Decide network approach (§3.3): gateway proxy skill vs. sandbox egress vs. n8n middleware
2. Define API key storage strategy
3. Define which external services Zuberi can call
4. Implement chosen approach
5. Test with a low-risk public API first

**Trigger conditions:**
- [ ] James makes network/security decision
- [ ] API key management strategy defined
- [ ] Tiers 1-3 stable

**Impact:** Build stage fully unlocked for apps that integrate external services.

---

### Tier 5: CEG Online — REQUIRES HARDWARE (EDUP ADAPTER)
**Capabilities unlocked:** C7 (n8n workflows), C9 (CXDB, full database), C16 (ccode sub-agent)
**Stages improved:** Build → ✅ (ccode delegation), Automate → 🟡

CEG is Zuberi's toolbox. Tools deploy incrementally as needed:

**What to do:**
1. CEG online (EDUP adapter → netplan → Tailscale)
2. SSH key KILO → CEG
3. Install and authenticate ccode CLI on CEG (headless auth — research needed)
4. Deploy SearXNG on CEG (move from KILO if deployed there first)
5. Deploy n8n on CEG via Docker
6. Deploy CXDB on CEG
7. Wire Zuberi ↔ each tool (SSH for ccode, REST for n8n, MCP for CXDB)

**Trigger conditions:**
- [ ] EDUP WiFi adapter arrives
- [ ] CEG joins tailnet
- [ ] Docker running on CEG
- [ ] Ccode headless auth method resolved

**Impact:** Sub-agent coding delegation. Automation workflows. Full database. Major capability unlock for $350K mission.

---

### Tier 6: GPU Upgrade + Expanded Agents — REQUIRES HARDWARE
**Capabilities unlocked:** C6 (full multi-agent), C10 (stronger local model), C13 (image gen)
**Stages improved:** All stages — quality and throughput ceiling raised

**What to do:**
1. Finalize GPU decision (RTX 3090 24GB vs. 2× 3090)
2. Install hardware
3. Load larger model (qwen3:32b or equivalent)
4. Consider additional specialist agents if mission demands it
5. (Optional) Deploy local image generation model

**Trigger conditions:**
- [ ] GPU decision finalized
- [ ] Hardware purchased and installed
- [ ] Tiers 1-5 stable
- [ ] Mission execution reveals need for more local compute

**Impact:** Zuberi operates at full capability across all stages.

---

## 6. Current State Summary

```
Stage Readiness:
  RESEARCH    ❌ → can unlock to 🟡 with Tier 1 (SearXNG, no hardware needed)
  STRATEGY    ✅   (improves with research inputs)
  MODEL       🟡 → can unlock to ✅ with Tier 2 (custom image, no hardware needed)
  DESIGN      ✅   (improves with diagram rendering in Tier 2)
  BUILD       ❌ → needs Tier 2 + Tier 4 + Tier 5 (ccode) for full unlock
  AUTOMATE    ❌ → needs Tier 5 (CEG + n8n)

Unlock Tiers:
  Tier 0  ████████████████████  Done
  Tier 1  ░░░░░░░░░░░░░░░░░░░░  Ready NOW (just needs James approval)
  Tier 2  ░░░░░░░░░░░░░░░░░░░░  Ready NOW (just needs James approval)
  Tier 3  ░░░░░░░░░░░░░░░░░░░░  Ready NOW (needs security decisions)
  Tier 4  ░░░░░░░░░░░░░░░░░░░░  Waiting (network/security decision)
  Tier 5  ░░░░░░░░░░░░░░░░░░░░  Waiting (EDUP adapter) ← CRITICAL for mission
  Tier 6  ░░░░░░░░░░░░░░░░░░░░  Waiting (GPU decision + hardware)
```

**Key insight:** Tiers 1, 2, and 3 can all be done NOW on current KILO hardware with zero cost. They require only config changes and Docker image builds. Combined, they move Zuberi from 2/6 stages ready to 4/6 stages ready. Tier 5 is the critical unlock for the $350K mission — it brings ccode sub-agent and automation online.

---

## 7. Phase Alignment

| Infrastructure Phase | FTAE Tier | Capabilities Unlocked |
|---------------------|-----------|----------------------|
| Phase 1 (complete) | Tier 0 | C1, C2, C3, C11 (partial) |
| — (no phase needed) | Tier 1 | C4 (web search via SearXNG) |
| — (no phase needed) | Tier 2 | C5, C8, C13 (partial), C15 |
| — (no phase needed) | Tier 3 | C14, C9 (SQLite) |
| Security decision | Tier 4 | C12 (external APIs) |
| Phase 3 (CEG online) | Tier 5 | C7 (n8n), C9 (CXDB), C16 (ccode sub-agent) |
| Phase 4 (GPU + expanded agents) | Tier 6 | C6 (full), C10, C13 (full) |

---

## Appendix: Version History

| Version | Date | Change |
|---------|------|--------|
| 0.1.0 | 2026-02-25 | Initial — 15 capabilities, 8 task types, maturity matrix |
| 0.2.0 | 2026-02-25 | Added: 6-stage execution path, 4-tier unlock sequence, trigger conditions |
| 0.3.0 | 2026-02-25 | Full solution sweep: concrete options for all 15 capabilities. Researched OpenClaw web search (SearXNG, Brave, Perplexity), sandbox network (custom image, setupCommand, proxy), browser (sandboxed browser, Firecrawl), API access (gateway proxy, n8n middleware), document generation (Python libs), database (SQLite interim), multi-agent (agent roster design). Restructured tiers to 0-6, identified Tiers 1-3 as immediately actionable with zero cost. |
| 0.4.0 | 2026-02-26 | Added C16 (coding sub-agent / ccode). Updated C6 (multi-agent) to reflect CEG-ccode architecture — ccode is first sub-agent, dispatched via SSH, builds on CEG filesystem. Updated C10 (stronger reasoning) — partially resolved by ccode sub-agent using Claude API. Updated §3.8 with decided architecture and dispatch pattern. Added §3.12 for C16 implementation path. Updated Tier 5 to include ccode deployment. Added C16 to Build stage dependencies. Updated current state summary — Tier 5 flagged as critical for $350K mission. n8n framed as automation layer in toolbox (not defining service). |

---
# END FTAE.md
