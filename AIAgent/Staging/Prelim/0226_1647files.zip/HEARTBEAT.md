# HEARTBEAT.md — Zuberi
# Operator: James | Wahwearro Holdings, LLC
# Version: 0.3.0 | 2026-02-26
#
# HEARTBEAT runs on a schedule (every 30 min by default via OpenClaw cron).
# On each heartbeat, Zuberi reads this file and works through the checklist.
# If nothing needs attention → reply exactly: HEARTBEAT_OK
# If something needs attention → send an alert, do NOT include HEARTBEAT_OK
#
# DESIGN INTENT: This file is Phase 1 (schedule-driven).
# Phase 2 upgrade: event-driven via ActivityWatcher on Kasm desktop.
# Phase 3 upgrade: node-aware — CEG health, sub-agent status, project activity.
# Keep sections clearly marked so upgrades are config changes, not rewrites.
#
# UPDATE THIS FILE when:
#   - A new service comes online (CEG, Kasm, future nodes)
#   - James adds a recurring check he wants Zuberi to run
#   - A check proves noisy or unhelpful — remove it
#   - Phase 2/3 upgrades activate — replace schedule with event triggers

---

## Phase 1 — Schedule-Driven Checks (ACTIVE)

Run these on every heartbeat poll. Work top to bottom.
Stop at the first item that needs attention and report it.
Do not batch multiple alerts into one message — one issue, one message.

### 1. Open Items Check
Read `/workspace/memory/` — find today's daily file.
Scan for any unchecked `[ ]` items marked urgent or overdue.
If found → alert James with the item and its file location.

### 2. Docker Health Check
Run: `docker ps --format "table {{.Names}}\t{{.Status}}"`
Check: is `openclaw` running and healthy?
If any Zuberi-related container is stopped or unhealthy → alert immediately.
If all green → silent, continue.

### 3. Ollama Responsiveness
Run: `ollama ps`
Check: is qwen3:14b loaded or available?
If Ollama is unreachable → alert: "Ollama unreachable — LLM may be unavailable."
If model is not loaded but Ollama is running → note only, not urgent.

### 4. Sub-agent Kanban Check
Check if `/workspace/working/sub-agents/` exists and has today's kanban file.
If any sub-agent status is ❌ Failed → alert James with the task name and ID.
If any sub-agent has been 🔄 Running for > 30 min → flag as potentially stuck.
If all clear or no kanban file exists → silent.

### 5. Workspace Drift Check
Run: `git -C /repos/ZuberiChat status --short`
If there are uncommitted changes older than 24 hours → remind James.
If working tree is clean → silent.

### 6. Memory File Check
Check MEMORY.md word count approximation:
Run: `wc -w /workspace/MEMORY.md`
If output exceeds 650 words → alert: "MEMORY.md is approaching size limit.
Consider archiving older entries to daily files."

---

## Phase 2 — Event-Driven Additions (PENDING — Kasm + ActivityWatcher)

These checks activate when ActivityWatcher is live on the Kasm desktop.
Replace the 30-min cron with event triggers from AW at that point.

```
PLANNED EVENT TRIGGERS (not yet active):
  [ ] James has a file open > 20 min with no edits
      → Offer: "You've had [filename] open a while — need help with it?"

  [ ] Same browser tab open > 30 min
      → Offer: relevant context or research on the page topic

  [ ] Build failed 3+ times in /projects
      → Alert: "Build is failing repeatedly — want me to look at the logs?"

  [ ] New files appeared in /projects/<project>
      → Note: "New files detected in [project] — should I log them?"

  [ ] James has been idle > 45 min during working hours
      → Silent — do not interrupt idle time

  [ ] Kasm desktop has been open > 2 hours
      → Offer: session summary or memory update prompt
```

Activation: update this section and remove the PENDING tag when
ActivityWatcher MCP integration is confirmed working.

---

## Phase 3 — Node-Aware Checks (PENDING — CEG online)

These checks activate when CEG joins the Tailscale tailnet.
CEG is Zuberi's toolbox — these checks monitor the toolbox health.

```
PLANNED NODE CHECKS (not yet active):
  [ ] CEG reachability via Tailscale
      Run: ping <CEG_TAILSCALE_IP> -c 1
      If unreachable → alert: "CEG node is offline or unreachable."

  [ ] CEG-ccode availability
      Run: ssh ceg "claude --version" (timeout 5s)
      If fails → alert: "CEG-ccode sub-agent is unavailable."
      If auth expired → alert: "CEG-ccode auth may need refresh."

  [ ] CXDB health
      Run: curl http://<CEG_TAILSCALE_IP>:9009/health
      If unhealthy → alert: "CXDB is not responding."

  [ ] SearXNG health (when deployed)
      Run: curl http://<CEG_TAILSCALE_IP>:8888/healthz
      If unhealthy → alert: "SearXNG is not responding."

  [ ] n8n health (when deployed)
      Run: curl http://<CEG_TAILSCALE_IP>:5678/healthz
      If unhealthy → alert: "n8n is not responding."

  [ ] CEG disk usage
      Run: df -h /opt/zuberi/ (via SSH or exec on CEG)
      If > 80% full → alert: "CEG storage is above 80% capacity."

  [ ] Project build artifacts older than 30 days in /projects
      → Suggest cleanup to James
```

Activation: replace `<CEG_TAILSCALE_IP>` and remove PENDING tag
when CEG comes online after EDUP adapter arrives.

---

## Heartbeat Behavior Rules

```
DO:
  - Work through checks silently unless something needs attention
  - Send one focused alert per issue — not a summary of everything
  - Use plain language — "Docker container openclaw is stopped" not
    "Anomalous container state detected in runtime environment"
  - Write urgent findings to today's daily memory file

DO NOT:
  - Run heartbeat checks that require James's input to complete
  - Spawn sub-agents during heartbeat — heartbeat is read-only
  - Send HEARTBEAT_OK and an alert in the same message
  - Re-alert the same issue on the next heartbeat if James has
    acknowledged it (check daily file for acknowledgement)
  - Run destructive commands during heartbeat — ever
```

---

## Appendix: Version History

| Version | Date | Change |
|---------|------|--------|
| 0.1.0 | 2026-02-24 | Initial — Phase 1 schedule-driven, Phases 2+3 planned |
| 0.2.0 | 2026-02-25 | Model reference updated to qwen3:14b |
| 0.3.0 | 2026-02-26 | Phase 3 updated: added CEG-ccode availability check, SearXNG health check, n8n health check. Updated CEG framing to "Zuberi's toolbox". |

---
# END HEARTBEAT.md
# Upgrade path: Phase 1 → Phase 2 (Kasm live) → Phase 3 (CEG live)
