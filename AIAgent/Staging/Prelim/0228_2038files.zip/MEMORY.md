# MEMORY.md — Zuberi
# Operator: James | Wahwearro Holdings, LLC
# Version: 0.5.0 | 2026-02-28
#
# RULES FOR THIS FILE:
#   - Keep under 600 words total — every word burns context on every turn
#   - This is curated wisdom, not raw notes (raw notes go in memory/YYYY-MM-DD.md)
#   - Only James or an explicit "update MEMORY.md" instruction modifies this file
#   - Never store secrets, tokens, or API keys here
#   - Review weekly — promote what matters, archive the rest

---

## Identity

I am Zuberi — a local, private AI assistant running on KILO for James at
Wahwearro Holdings, LLC. I run on qwen3:14b-fast via Ollama (no-think template
for speed; original qwen3:14b available for deep reasoning). I have no cloud
dependencies. Privacy and local-first operation are core values, not constraints.

I am an apprentice. I learn through work with James. My soul and behavior
are defined in SOUL.md and AGENTS.md respectively.

---

## James — Context & Preferences

**Who:** James Mwaweru, operator and collaborative partner.
James built this system deliberately — local, private, autonomous.
He values precision over speed, honesty over agreeability, and
substance over performance.

**Working style:**
- Methodical. Provides detailed context when troubleshooting.
- Researches before deciding — brings sources, confers before acting.
- Prefers step-by-step guidance on complex tasks.
- Comfortable with PowerShell, Docker, and manual config editing.
- Makes deliberate architectural decisions — asks "why" before "how".

**Communication preferences:**
- Direct. No filler. No excessive affirmation.
- Short responses for simple tasks, depth when the task demands it.
- Flag uncertainty explicitly — James would rather know than be misled.
- Push back when something seems wrong — once, clearly, then defer.

**Tools James uses:**
- Windows (KILO) + WSL2 + Docker
- PowerShell for system administration
- Ollama for local model inference
- OpenClaw as agent runtime
- Tauri + TypeScript for app development
- Tailscale for private networking (account: jamesmwaweru@gmail.com)
- Claude Code (ccode) v2.1.59 on KILO — James's personal coding tool

---

## Active Projects

**1. Zuberi App (ZuberiChat repo)**
Tauri + TypeScript desktop app — renamed from ZuberiChat to Zuberi.
Repo: `C:\Users\PLUTO\github\Repo\ZuberiChat`
Status: v0.1.0 installed. Live and responding via OpenClaw.
Next: Model selector UI, app features.

**2. OpenClaw on KILO**
Running in Docker v2026.2.26, dashboard at localhost:18789.
Model: qwen3:14b-fast via Ollama (no-think, 1-2s responses).
Security: sandbox=non-main, elevated exec for webchat.
Memory: hybrid search (BM25 0.3 + vector 0.7), embedding cache (50K).
Skills: searxng, cxdb, ollama. All deployed.
Status: Stable. Zuberi responding end-to-end.

**3. Mission AEGIS (strategy phase)**
Target: $350,000 in 180 days. Start date pending.
Dual tracks: revenue + capability growth (equal priority).
Status: Strategy discussion in progress. MISSION-AEGIS.md not yet created.

**4. Sub-Agent Architecture (CEG online, ccode pending)**
CEG-ccode: Claude Code CLI on CEG — headless auth TBD.
CEG = Zuberi's toolbox, online at 100.100.101.1 (Tailscale).
Services live: SearXNG (8888), n8n (5678), CXDB (9009/9010).
Reference repos: /opt/zuberi/reference/ (Ruflo, Automaton).

---

## Infrastructure Baseline

```
KILO (brain): RTX 3060 12GB, 64GB RAM, OpenClaw v2026.2.26, ccode v2.1.59
  Models: qwen3:14b-fast (active), qwen3:14b, qwen3-vl:8b, gpt-oss:20b
  All on E:\ollama\models (~27GB)
  VRAM: 12GB shared — one large model + desktop apps. Unload for video.
CEG (toolbox): M701q, Ubuntu 24.04.4, Tailscale 100.100.101.1
  Live: SearXNG, n8n, CXDB (all Tailscale-only, restart=always)
  Pending: ccode sub-agent (headless auth TBD)
```

---

## Lessons Learned

- 2026-02-24 | Initial deployment.
- 2026-02-25 | gpt-oss:20b at 95% VRAM causes 30/70 CPU/GPU split. Swapped to qwen3:14b.
- 2026-02-27 | netplan does NOT manage USB WiFi on Ubuntu Server. Use systemd wpa_supplicant@ + dhcpcd@.
- 2026-02-27 | OpenClaw does NOT support custom search/MCP via openclaw.json. Use workspace skills.
- 2026-02-27 | Docker DNS inside containers fails with systemd-resolved. Fix: {"dns":["8.8.8.8","1.1.1.1"]}.
- 2026-02-27 | CXDB has no pre-built Docker image. Build from source with --network=host.
- 2026-02-28 | sandbox.mode="all" requires Docker socket in gateway container. Use "non-main" instead.
- 2026-02-28 | OpenClaw reasoning:true sends think:"low" to Ollama → 400 error. Set reasoning:false; Qwen3 thinks natively.
- 2026-02-28 | Qwen3 thinking adds 3-6s latency (~100 hidden tokens). Custom no-think template (qwen3:14b-fast) drops to 1-2s.
- 2026-02-28 | 9.3GB model + desktop apps = 228MB free VRAM. Unload model for video/DRM/gaming.
- 2026-02-28 | OLLAMA_MODELS env var must be set at user level. Ollama runs as user process, not service.

---

## Open Questions

- [ ] First live SearXNG + CXDB test from Zuberi webchat (skills deployed, untested end-to-end)
- [ ] Ccode headless auth on CEG — research needed
- [ ] Model selector UI in Zuberi app (design + build)
- [ ] Arc position review: when does Zuberi graduate from Apprentice?
- [ ] Mission AEGIS strategy + MISSION-AEGIS.md creation
- [ ] CXDB Total Memory Migration (HORIZON.md)

---
# Word count target: <600 | Current: ~590
# Next review: after first 5 live sessions
# END MEMORY.md
