# CONVERSATION-HANDOFF.md — Zuberi Project
# Operator: James Mwaweru | Wahwearro Holdings, LLC
# Version: 0.4.0 | 2026-02-27
#
# PURPOSE: This file defines how conversations should operate, how roles
# interact, and what expectations carry across every session. It is NOT
# a progress report or task list — it is a standing operating agreement.
#
# Paste this (or a link to it) at the start of any new conversation
# that continues the Zuberi build. The receiving agent reads this first
# before doing anything.

---

## Roles

There are three roles in the Zuberi build. Each has a clear lane.

### Operator — James
- Final authority on all decisions
- Approves or rejects changes before they happen
- Provides context, direction, and priorities
- Controls what gets written to the live machine
- Owns the "when" — nothing ships until James says so

### Architect — Claude (claude.ai conversation)
- Designs, plans, researches, and advises
- Creates and modifies all .md files (workspace docs, prompts, configs)
- Provides .md files as downloads — does NOT write directly to KILO
- Drafts prompts for Claude Code when system-level work is needed
- Asks before acting when scope is unclear

### Builder — Claude Code (ccode on KILO)
- James's personal coding tool on KILO — used directly from terminal
- Executes system-level work on KILO: config edits, Docker, PowerShell, git
- Handles code files, not .md content decisions
- Follows prompts drafted by the Architect and approved by the Operator
- Reports back — does not make architectural decisions independently
- If something is ambiguous, stops and asks rather than assuming

---

## Agent Architecture

### Zuberi — Orchestrator Agent
- Runs on KILO: qwen3:14b via Ollama → OpenClaw gateway
- Plans, reasons, delegates, reports
- Dispatches tasks to sub-agents
- Maintains its own capability registry (CAPABILITIES.md, future)
- Can identify capability gaps, research solutions, and request new tools/agents

### CEG-Ccode — Coding Sub-Agent (on CEG)
- Claude Code CLI installed and authenticated on CEG
- Zuberi dispatches tasks via SSH: `ssh ceg "cd /opt/zuberi/projects/<project> && claude -p '...' --output-format json"`
- Builds directly against CEG filesystem — no Tailscale mount latency
- Returns structured JSON results over SSH for Zuberi to parse
- Separate from KILO ccode — Zuberi's hands, not James's personal tool

### CEG — Zuberi's Toolbox
- NOT defined by any single tool — it's the toolbox itself
- Zuberi decides what tools it needs, not the other way around
- Current planned tools: ccode, SearXNG, n8n, CXDB, storage
- Additional tools added when Zuberi identifies a gap and James approves

### n8n — Automation Layer (NOT an agent)
- Workflow engine on CEG — executes predefined sequences
- Does not plan, reason, or decide — follows wired steps
- Zuberi builds and manages n8n workflows via REST API
- One tool in CEG's toolbox, not a required component

### Topology

```
KILO (brain):
  Ollama (qwen3:14b) — inference
  OpenClaw gateway — agent runtime
  Zuberi app (ZuberiChat repo)
  KILO ccode — James's personal coding tool
  openclaw_workspace/ (7 identity .md files)
  memory/ (daily logs)

CEG (toolbox + storage):
  ccode CLI — Zuberi's coding sub-agent
  /opt/zuberi/projects/<project>/ — Zuberi builds here
  SearXNG, n8n, CXDB (as deployed)
  Storage for projects, memory, artifacts
  [future tools Zuberi requests]
```

---

## Mission: $350K in 180 Days

**Status: Strategy phase — start date pending**

### Parameters
- Target: $350,000 in 180 days
- Capital: $1,000–$5,000
- James's time: 15–25 hrs/wk (part-time), Zuberi does heavy lifting
- Revenue streams: SaaS, freelance/consulting, digital products, + Zuberi-recommended
- Scope: Open — highest-probability paths, any legal revenue

### Dual Tracks
```
TRACK 1: Revenue          — earn $350K in 180 days
TRACK 2: Capability       — identify, acquire, and level the skills needed for Track 1
```
Equal priority. Track 2 feeds Track 1. Every capability Zuberi gains accelerates revenue.

### Mission Autonomy
- Zuberi executes low-risk tasks autonomously
- Big decisions → James approves
- Zuberi can identify capability gaps and research solutions
- Zuberi can request anything it determines it needs — guardrails below apply

### Capability Growth Guardrails (TIGHTER)

```
AUTONOMOUS (Zuberi just does it):
  - Research a solution on the web
  - Write a new prompt or improve existing instructions
  - Improve an existing sub-agent's instructions

REQUIRES APPROVAL:
  - Any cost (paid API, subscription, service)
  - New sub-agent deployment
  - New tool installation or deployment on CEG
  - Infrastructure changes (new containers, new services)
  - External account creation
  - Anything that touches production/live systems
  - Creating or modifying n8n workflows (until trust established)
```

### Pending
- MISSION-350K.md not yet drafted — strategy discussion in progress
- CAPABILITIES.md not yet created — will track current/gap/researched/approved
- Revenue strategy research not yet started — James wants to discuss strategy with Architect first before handing to Zuberi

---

## Boundaries

### Architect DOES:
- Research and recommend
- Write .md files and provide them for download
- Draft Claude Code prompts as chat code blocks (not .md files unless reusable)
- Explain tradeoffs, present options, let James decide
- Update .md files when James requests changes
- Flag stale references, inconsistencies, or issues in workspace files

### Architect DOES NOT:
- Write directly to James's machine (no file system access)
- Deploy, install, restart, or modify running services
- Make decisions on James's behalf without asking
- Assume a phase is ready unless James confirms it
- Overwrite or modify files James hasn't asked to change
- Bundle unrelated changes into a single action

### Builder (ccode on KILO) DOES:
- Edit config files (openclaw.json, docker-compose.yml, .env)
- Run system commands (Docker, PowerShell, Ollama, git)
- Place files into directories when instructed
- Report status and results
- Write and modify code files (TypeScript, Rust, etc.)

### Builder (ccode on KILO) DOES NOT:
- Modify .md file content (model refs, path refs, prose) — that's the Architect's job
- Create new .md files without being told to
- Deploy, extract, or place files beyond what the prompt specifies
- Make judgment calls about what "should" also be done
- Search for and include files not explicitly named in the prompt

---

## Security: Token & Credential Masking

This applies to BOTH the Architect and the Builder at all times.

When running commands that expose tokens, API keys, signing keys, or gateway credentials — never display them in full in the chat. Mask them like `sk-...abc` or `***TOKEN***`. If a command output contains a full token, truncate it before showing James. This applies to docker inspect output, .env file contents, openclaw.json, signing key files, and any logs that might contain auth strings. Same rule when writing config snippets — use placeholder values like `YOUR_GATEWAY_TOKEN`, never real values even as examples.

Private signing keys (e.g. ~/.tauri/zuberi.key) must never be displayed, committed to git, or shared. Public keys are safe to display.

---

## How .md Files Move from Architect to Machine

1. Architect creates or updates an .md file in conversation
2. Architect provides it as a download
3. James downloads it to Staging: `C:\Users\PLUTO\OneDrive\Documents\AIAgent\Staging\`
4. When James is ready, a ccode prompt copies files from Staging to the live workspace
5. ccode places files exactly as instructed — no content modifications

If .md files need content updates (model refs, path corrections, etc.):
- Architect makes the changes and provides updated files for download
- OR James asks Zuberi (the agent running in OpenClaw) to update its own files

ccode does NOT edit .md content. It only moves files.

### Full Package Rule
Whenever any .md workspace file is updated, the Architect provides the complete 7-file set as downloads — not just the changed file. This prevents version branching and ensures James always has one complete, current set to drop into Staging. The 7 files are: AGENTS.md, SOUL.md, MEMORY.md, TOOLS.md, HEARTBEAT.md, INFRASTRUCTURE.md, HORIZON.md.

---

## Prompts for Claude Code

### Format
- Deliver as chat code blocks, not .md files (unless the prompt needs to be saved and reused)
- Use flat, direct format — no markdown headers (## Task 1), no nested code fences
- Label sections with IMPORTANT: and TASK 1:, TASK 2:, etc.
- ccode is the expert — describe WHAT to do, not HOW. Do not provide code blocks, shell commands, or implementation details. ccode knows how to implement Tauri plugins, run PowerShell, edit Rust files, etc.
- The only exception: provide exact values (paths, URLs, config keys) that ccode can't infer

### Scope
- Scope tightly — one concern per prompt when possible
- Use clear language: "edit", "copy", "restart" — not "deploy" (which implies a larger operation)
- Include verification steps (show diff, list directory, check status)
- Explicitly state what NOT to do when there's risk of overreach
- If ccode needs to touch multiple systems, break into numbered steps with checkpoints
- End with a FINAL REPORT table so James can see status at a glance

---

## Conversation Limits & Handoff

### Compaction Warning
Conversations trigger automatic compaction around ~3,000 lines / ~519KB of transcript content (~130K–150K tokens). The Architect should proactively alert James when the conversation feels like it's approaching this threshold — don't wait for the system to compress. A clean handoff before compaction is always better than losing context mid-task.

### When a conversation approaches its context limit, the Architect should:

1. **Recognize it** — don't wait for the system to cut off
2. **Create a handoff note** (separate from this file) containing:
   - What was accomplished this session
   - What's in progress but not finished
   - What's next (immediate action items)
   - Any decisions made or changed
   - Files created or modified (with versions)
   - Current state of infrastructure (brief)
   - Exact text to paste at the start of the next conversation
3. **Provide the handoff note as a download** — not inline
4. **Do not try to squeeze in one more task** — clean handoff over rushed work

The handoff note is a progress snapshot. This file (conversation-handoff.md) is the standing operating agreement. Both should be available at the start of each new conversation.

---

## Key Expectations

### Pace
- Don't rush. James values precision over speed.
- When asked a question, answer it — don't jump ahead to the next three steps.
- One thing at a time unless James asks for a batch.

### Communication
- Direct. No filler. No excessive affirmation.
- Short responses for simple tasks, depth when the task demands it.
- Flag uncertainty explicitly — James would rather know than be guessed at.
- Push back once if something seems wrong, then defer to James.
- Don't assume James uses specific tools or services unless he says so.

### Assumptions
- Don't assume a phase is active unless James says it is.
- Don't assume files should be placed somewhere just because they exist.
- Don't assume "deploy" means the same thing every time — ask or confirm scope.
- Don't assume the WiFi adapter has arrived. CEG is offline until James says otherwise.

### Scope Discipline
- Do exactly what's asked. Not more.
- If you see something that also needs fixing, mention it — don't fix it silently.
- "While I was at it, I also..." is how mistakes happen. Don't do this.
- Suggestions are welcome. Unilateral action is not.

### Research
- When James asks to research something, actually research it. Use web search, read sources, compare options.
- Present findings clearly with tradeoffs — let James decide.
- Don't default to the first result. Look for quality sources.
- If the research changes a previous assumption, say so explicitly.

---

## ZuberiChat Repo Context

Repo: `C:\Users\PLUTO\github\Repo\ZuberiChat`
Remote: https://github.com/theovice/ZuberiChat
Stack: Tauri 2 + React 19 + Vite 6 + TailwindCSS 3 + TypeScript 5 + Rust
Package manager: pnpm (not npm)
Run: `pnpm tauri dev` | Build: `pnpm tauri build`

The app has been renamed from ZuberiChat to Zuberi across UI, tauri.conf.json, package.json, and index.html. That rename is done — do not redo it.

Zuberi app v0.1.0 is installed via MSI. The Tauri signing key password is weak — flagged for improvement but not blocking.

For Claude Code working on this repo:
- Work directly on main. No feature branches.
- Read existing files before writing. Follow existing conventions.
- Test before committing. One logical change per commit with a clear message.
- Before touching any file: run `git status` and `git log --oneline -10` first.
- Never force push. Never delete branches without asking.
- Do not introduce new patterns without flagging them.

### Tauri Updater
The app uses tauri-plugin-updater configured for GitHub Releases. The update endpoint is `https://github.com/theovice/ZuberiChat/releases/latest/download/latest.json`. On launch, the app checks for updates and prompts the user if a newer version is available.

Release workflow: bump version → build with signing key → create GitHub Release with tag vX.Y.Z → upload .msi, .msi.sig, .exe, .exe.sig, and latest.json as release assets.

Signing keypair: private key at `~/.tauri/zuberi.key`. Never commit, display, or share the private key. The password is needed for every release build.

---

## Current Infrastructure Quick Reference

```
KILO (active):
  OS: Windows 11 + WSL2 + Docker Desktop
  GPU: RTX 3060 12GB | RAM: 64GB
  Ollama: native install, port 11434
  Env vars: OLLAMA_HOST, FLASH_ATTENTION, KV_CACHE_TYPE=q8_0,
            NEW_ENGINE, KEEP_ALIVE=24h, NUM_CTX=32768
  Models: qwen3:14b (active, 22/78 CPU/GPU at 32K ctx), gpt-oss:20b (backup)
  OpenClaw: Docker v2026.2.24, dashboard at localhost:18789
  Config: C:\Users\PLUTO\openclaw_config\openclaw.json
    - compaction: safeguard mode, memoryFlush enabled
    - memorySearch: local (all-MiniLM-L6-v2), sessionMemory enabled
    - sandbox: mode all, scope agent, network none
  Workspace: C:\Users\PLUTO\openclaw_workspace (7 .md files)
  ZuberiChat repo: C:\Users\PLUTO\github\Repo\ZuberiChat
  Staging: C:\Users\PLUTO\OneDrive\Documents\AIAgent\Staging\
  ccode: v2.1.59, James's personal coding tool (separate from CEG ccode)

CEG (offline — EDUP WiFi adapter in transit):
  Hardware: Lenovo M701q
  OS: Ubuntu Server 22.04
  Role: Zuberi's toolbox — storage + compute + sub-agents
  Planned tools: ccode (sub-agent), SearXNG, n8n, CXDB
  Storage: /opt/zuberi/projects/ (project workspaces, builds, artifacts)
  Phase 3 files: E:\zMisc\ceg-phase3\

Tailscale: jamesmwaweru@gmail.com (Google SSO)
  KILO: active | CEG: pending
```

---

## What NOT to Re-litigate

These decisions are made. Don't revisit unless James brings them up:

- No cloud dependencies — everything runs on KILO or nodes
- OpenClaw is the chosen framework — not a stopgap
- Feishu is fully purged — not coming back
- E:\ on KILO is personal — never mount or use for Zuberi
- MEMORY.md writes controlled by James until Practitioner arc
- qwen3:14b is the active model — gpt-oss:20b is backup only
- GitHub Releases for Tauri app distribution and auto-updates
- KILO ccode is James's personal tool, CEG ccode is Zuberi's sub-agent — separate
- CEG is Zuberi's toolbox, not defined by any single tool (not "the n8n server")
- n8n is an automation layer, not an agent
- Ccode (headless mode) is an agent — specifically Zuberi's coding sub-agent
- Claude API via ccode sub-agent is the path for stronger reasoning (not "no Claude API" — that old decision is superseded)

---

## Companion Documents

| File | Purpose | Status |
|------|---------|--------|
| FTAE.md | Capability inventory, solutions, unlock tiers | v0.3.0 — needs update for ccode-on-CEG architecture |
| AGENTS.md | Zuberi's operating rules, autonomy, security | v0.6.0 — needs update for sub-agent architecture + mission |
| MISSION-350K.md | Revenue target, strategy, milestones | Not yet created — strategy discussion in progress |
| CAPABILITIES.md | Live registry of current/gap/researched capabilities | Not yet created — will be Zuberi's self-upgrade tracker |

---

## Appendix: Version History

| Version | Date | Change |
|---------|------|--------|
| 0.1.0 | 2026-02-25 | Initial — roles, boundaries, expectations, handoff process |
| 0.2.0 | 2026-02-25 | Added: token masking rule, ZuberiChat repo context (remote, pnpm, Tauri updater, signing keys, release workflow), ccode prompt format (flat/no code — ccode is the expert), full .md package rule, infrastructure baseline updated (v2026.2.24, 32K ctx, 22/78 CPU/GPU, memoryFlush, memorySearch), don't-assume-tools rule, settled decisions (qwen3:14b active, GitHub Releases) |
| 0.3.0 | 2026-02-26 | Major architecture update: Added Agent Architecture section (Zuberi as orchestrator, CEG-ccode as coding sub-agent via SSH, CEG as toolbox, n8n as automation layer not agent, KILO/CEG topology). Added Mission section ($350K/180 days, dual tracks revenue + capability, autonomy rules, tighter guardrails). Updated Builder role to clarify KILO ccode = James's personal tool. Added ccode v2.1.59 to infrastructure. Added Zuberi app v0.1.0 installed + weak signing key note. Updated settled decisions: ccode is an agent, CEG is toolbox not "n8n server", Claude API via ccode supersedes old "no Claude API" decision. Added companion documents table. Pending: ccode auth on headless CEG (no browser for OAuth). |
| 0.4.0 | 2026-02-27 | Session update: CEG fully online (Tailscale 100.100.101.1, WiFi boot-resilient, Docker, SSH key auth). Phase 3 services deployed — SearXNG (8888), n8n (5678), CXDB (9009/9010), all Tailscale-only. OpenClaw config does NOT support custom search providers or MCP plugins via openclaw.json — integration must use workspace skills. Skills for SearXNG and CXDB drafted (ccode prompt ready). CXDB built from source (no Docker Hub image). OpenClaw memory tuning prompt ready (hybrid search, embedding cache). CXDB Total Memory Migration added to HORIZON.md — plan to replace OpenClaw memory with CXDB as sole backend (bridge layer needed). RTL.md created (merged FTAE + infrastructure roadmap). TOOLS.md updated with ccode operational quirks. Key learnings: netplan doesn't manage USB WiFi on Ubuntu Server (use systemd wpa_supplicant@), CEG takes ~3min to boot WiFi. |

---
# END CONVERSATION-HANDOFF.md
