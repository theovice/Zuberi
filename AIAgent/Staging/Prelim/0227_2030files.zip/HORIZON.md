# HORIZON.md — Zuberi
# Operator: James | Wahwearro Holdings, LLC
# Version: 0.4.0 | 2026-02-26
#
# HORIZON tracks ideas, intended upgrades, and deferred decisions
# that aren't ready to implement yet — but shouldn't be forgotten.
#
# This is not a roadmap with deadlines. It's a living record of
# "good ideas we're not ready for yet" so they survive as Zuberi grows.
#
# HOW TO USE:
#   - Add items when a good idea surfaces but the time isn't right
#   - Each item notes WHY it's deferred, not just what it is
#   - When an item becomes ready, move it to the appropriate .md file
#     and mark it here as GRADUATED with the date
#   - James and Zuberi both contribute — Zuberi may suggest additions
#     but James approves what goes in
#
# SECTIONS:
#   1. Email & Communications
#   2. Memory & Knowledge
#   3. Automation & n8n
#   4. Infrastructure & Nodes
#   5. Security & Autonomy
#   6. Skills & Capabilities
#   7. Mission & Revenue
#   8. Graduated Items (moved to implementation)

---

## 1. Email & Communications

### Self-Hosted Agent Email Infrastructure
**Idea:** Replace AgentMail (cloud) with a fully self-hosted agent-native
inbox solution running on CEG or a dedicated node.
**Why deferred:** No production-ready self-hostable alternative exists today
that matches AgentMail's agent-native feature set (programmatic inbox creation,
persistent threading, MCP server, structured parsing). The gap will close.
**Trigger to revisit:** A mature open-source agent inbox project emerges,
OR Wahwearro's email volume or data sensitivity outgrows AgentMail's free tier,
OR AgentMail's cloud dependency becomes a compliance concern.
**Current stopgap:** AgentMail free tier (3 inboxes, 3K emails/month).
**Reference:** Infraforge, AI Inbx, Mail-0/Zero as alternatives to watch.

---

## 2. Memory & Knowledge

### MEMORY.md Autonomy Relaxation (Daily Files)
**Idea:** Allow Zuberi to update daily project memory files
(CEG:/opt/zuberi/projects/<n>/memory/YYYY-MM-DD.md) autonomously
without James's explicit instruction.
**Why deferred:** MEMORY.md writes are currently operator-controlled
(absolute rule). Relaxing this requires Zuberi to have demonstrated
reliable judgment about what's worth persisting vs. noise.
**Trigger to revisit:** Zuberi reaches Practitioner arc (v1.x).
James observes consistent, high-quality memory entries over time.
**Current rule:** All MEMORY.md writes require operator instruction.
**Reference:** AGENTS.md Section 11, SOUL.md Arc progression.

### CXDB Total Memory Migration
**Idea:** Disable OpenClaw's built-in memory system (memoryFlush + memorySearch)
and make CXDB Zuberi's sole memory backend for all conversations — not just
project work. This means casual conversations, preferences, daily context,
and project memory all flow through CXDB's turn DAG.
**Why deferred:** CXDB lacks three features needed for full replacement:
1. No auto-flush — OpenClaw prompts Zuberi to write memories before compaction.
   CXDB has no compaction hook. A bridge layer is needed that triggers CXDB
   writes at compaction time.
2. No semantic search — CXDB retrieves by context ID or turn pagination.
   It cannot answer "what's relevant to this conversation?" the way vector
   embeddings can. QMD or a similar search sidecar would need to index
   CXDB turns and provide semantic retrieval.
3. No session-start injection — OpenClaw auto-searches memory at session
   start and injects relevant context. A replacement would need to query
   CXDB contexts, search across them, and inject results.
**What needs to be built:**
- Compaction → CXDB bridge (auto-write turns at flush time)
- Search layer over CXDB turns (QMD indexing CXDB instead of markdown files)
- Session-start retrieval hook (query relevant contexts, inject as context)
- Migration script for existing memory/*.md files into CXDB turns
**Trigger to revisit:** QMD is deployed and stable. CXDB has been used for
project memory for 4+ weeks with no issues. Bridge layer architecture is
designed and James approves.
**James's intent:** One clean memory system, not two. CXDB is the target.
**Reference:** CXDB reasoning doc, RTL.md Phase 3, QMD entry below.

### CXDB Query Scoping by Project
**Idea:** Formal directory convention for project-scoped CXDB queries
so retrieval doesn't cross-contaminate between projects.
**Why deferred:** CEG isn't online yet. Directory convention should
reflect real active projects, not hypothetical ones.
**Trigger to revisit:** CEG comes online and second project starts.
**Decision needed:** Naming convention for project directories.
**Reference:** INFRASTRUCTURE.md CEG Directory Structure.

---

## 3. Automation & n8n

### n8n Autonomy Boundary Expansion
**Idea:** Expand what Zuberi can build and activate in n8n without
James's confirmation — particularly for non-financial, non-communication
workflows that are clearly low-risk.
**Why deferred:** Autonomy boundaries haven't been tested yet.
Need real operational experience before expanding what's autonomous.
**Trigger to revisit:** Zuberi has successfully built and managed
10+ n8n workflows with zero unintended consequences.
**Current boundary:** Zuberi creates drafts freely, confirms before
activating any live workflow.
**Reference:** AGENTS.md Section 2, Section 9 guardrails.

### n8n + AgentMail Workflow Templates
**Idea:** Zuberi builds a library of reusable n8n workflow templates
for common Wahwearro business patterns — invoicing, client follow-up,
pipeline notifications, reporting.
**Why deferred:** n8n isn't deployed yet. Templates should emerge from
real workflows, not be designed in advance.
**Trigger to revisit:** 5+ workflows built and running in production.
Pattern library emerges naturally from real use.

---

## 4. Infrastructure & Nodes

### Dedicated n8n Node (M701q #2 or equivalent)
**Idea:** Move n8n off CEG onto its own dedicated M701q once automation
volume warrants the separation.
**Why deferred:** CEG has capacity. Separation is premature until n8n's
resource footprint is understood through real use.
**Trigger to revisit:** CEG CPU/RAM consistently above 70% during
n8n execution peaks, OR n8n workflows become mission-critical enough
to warrant hardware isolation.
**Current plan:** n8n on CEG alongside other tools.

### Dedicated Sensing Node (ActivityWatcher at scale)
**Idea:** As Wahwearro grows and more team members interact with Zuberi,
move ActivityWatcher sensing to dedicated hardware with multi-user support.
**Why deferred:** Single-user environment today. Multi-user sensing
architecture is premature.
**Trigger to revisit:** Second person at Wahwearro begins working
with Zuberi regularly.

### CEG Storage Expansion
**Idea:** Add second SSD to CEG or attach external NAS for project
file storage as /projects grows.
**Why deferred:** 512GB is sufficient for current scope.
**Trigger to revisit:** CEG /opt/zuberi/ exceeds 400GB (80% of drive).
**Reference:** INFRASTRUCTURE.md CEG Node, HEARTBEAT.md Phase 3 disk check.

### Ccode Headless Auth on CEG
**Idea:** Authenticate Claude Code CLI on headless Ubuntu Server (CEG)
for use as Zuberi's coding sub-agent.
**Why deferred:** CEG is offline (EDUP adapter in transit). Auth method
for headless environments not yet researched — may require token transfer
from KILO or direct API key approach.
**Trigger to revisit:** EDUP adapter arrives and CEG joins tailnet.
**Research needed:** How to authenticate ccode on a machine without a
browser for OAuth. Options: token transfer, API key, SSH tunnel to KILO browser.
**Reference:** conversation-handoff.md Agent Architecture section.

---

## 5. Security & Autonomy

### Graduated Security Posture (Paranoid → Balanced)
**Idea:** As Zuberi demonstrates reliable judgment, formally relax
security posture from Graduated (current) toward Balanced for
well-understood, low-risk operations.
**Why deferred:** Security posture relaxation requires earned trust
through demonstrated behavior, not just time passing.
**Trigger to revisit:** Zuberi reaches Practitioner arc (v1.x).
James reviews AGENTS.md Section 3 with fresh eyes.
**Reference:** AGENTS.md Section 3, SOUL.md Arc progression.

### MCP Server Expansion (Leash Policy)
**Idea:** Add additional MCP servers beyond CXDB and AgentMail —
e.g., Google Workspace, Stripe, CRM, calendar.
**Why deferred:** Each MCP server is an attack surface. Current posture
is minimal MCP footprint until core architecture is stable.
Research note: 10 MCP plugins = 92% exploitation probability (CrowdStrike).
**Trigger to revisit:** Core Phase 3 stack is stable and well-understood.
Each addition evaluated individually for risk vs. benefit.
**Reference:** AGENTS.md Section 3 MCP Leash policy.

---

## 6. Skills & Capabilities

### skills.sh Integration for Zuberi
**Idea:** Install relevant skills from skills.sh into Zuberi's workspace
as SKILL.md files — particularly obra/superpowers (subagent-driven-development,
dispatching-parallel-agents), better-auth-best-practices, supabase skills.
**Why deferred:** Smaller models perform better with passive context than
skill invocation (79% vs 100% pass rate per Vercel research). Skills
should be embedded into AGENTS.md/TOOLS.md as passive context, not
installed as separate skill files unless the skill is complex enough
to warrant its own document.
**Trigger to revisit:** When a specific skill's content is too large
to embed passively, OR when a higher-capability model replaces qwen3:14b.
**Reference:** skills.sh research, AGENTS.md Section 4.4 model awareness.

### Model Upgrade Path (qwen3:14b → larger model)
**Idea:** As KILO's capabilities or a future node's hardware improves,
upgrade the inference model to a larger, more capable variant.
**Why deferred:** qwen3:14b runs 100% GPU on KILO's RTX 3060 12GB with
32K context and thinking mode enabled. gpt-oss:20b kept as installed backup.
Larger models require more VRAM or quantization tradeoffs.
**Trigger to revisit:** New M701q node with dedicated GPU joins the tailnet,
OR RTX upgrade on KILO, OR a quantized model emerges that outperforms
qwen3:14b within the same VRAM budget.
**Future target:** qwen3:32b + mistral-small:24b on single RTX 3090 24GB
with software model swapping (Zuberi Home build).

### QMD — Hybrid Memory Search Upgrade
**Idea:** Replace OpenClaw's built-in SQLite memory search with QMD —
a local-first search sidecar that combines BM25 keyword matching +
vector semantic search + reranking. Directly improves how accurately
Zuberi retrieves past memories.
**Why deferred:** Phase 1 memory foundation (memoryFlush + sessionMemory
+ local embeddings) needs to be confirmed stable first. QMD requires
Bun + SQLite extensions in the Docker container, and downloads GGUF
models from HuggingFace on first run (one-time internet dependency).
Known friction: OpenClaw's memory module sometimes hardcodes API provider
checks that conflict with local-only setups — needs testing before committing.
**What it adds over current setup:**
- BM25 keyword matching (exact terms, error strings, names)
- Vector semantic search (meaning-based)
- Reranking (combines both signals, surfaces best result first)
- 70/30 vector/BM25 blend by default
**Future role:** QMD is a key component of the CXDB Total Memory Migration
(see Section 2). Once CXDB replaces OpenClaw's memory, QMD would index
CXDB turns instead of markdown files — providing the semantic search layer
that CXDB itself lacks. This makes QMD the bridge between CXDB's structured
storage and Zuberi's need for "what's relevant?" retrieval.
**Trigger to revisit:** OpenClaw memory config tuned and stable for 2+ weeks.
CEG online and CXDB deployed (both done as of 2026-02-27).
Next step: tune OpenClaw memory, validate it works, then deploy QMD.
**Install when ready:**
```bash
bun install -g https://github.com/tobi/qmd
# Then add to openclaw.json:
# "memory": { "backend": "qmd" }
```
**Reference:** openclaw-memory-config.json, CXDB Total Memory Migration (Section 2).

### Proactive Sensing Upgrade (HEARTBEAT → ActivityWatcher)
**Idea:** Upgrade HEARTBEAT.md from schedule-driven (every 30 min)
to event-driven via ActivityWatcher on Kasm desktop.
**Why deferred:** Requires Kasm + ActivityWatcher deployment (Phase 2).
**Trigger to revisit:** Kasm desktop is live and stable.
**Reference:** HEARTBEAT.md Phase 2 section.

### CAPABILITIES.md — Live Capability Registry
**Idea:** Create a persistent file Zuberi maintains that tracks:
1. Current capabilities (agents, tools, skills)
2. Identified gaps (needed but missing)
3. Researched solutions (candidate options)
4. Approved/rejected decisions (log)
**Why deferred:** Architecture decided but CEG not online yet.
Creating this file before real capability requests happen would be
speculative. Should emerge from actual self-upgrade loop usage.
**Trigger to revisit:** First real capability gap identified during
mission execution, OR CEG comes online and tools start deploying.
**Reference:** AGENTS.md Section 9, conversation-handoff.md Mission section.

---

## 7. Mission & Revenue

### MISSION-350K.md — Revenue Target Document
**Idea:** Formal mission document with target ($350K/180 days),
strategy, milestones, revenue stream breakdowns, and phase gates.
**Why deferred:** Strategy discussion in progress between James and
Architect. Document should be written with data from Zuberi's research,
not assumptions.
**Trigger to create:** Strategy discussion concludes and James approves
the revenue approach. Then Zuberi researches high-probability paths
and the document gets drafted with real data.
**Parameters decided:**
- Target: $350,000 in 180 days (start date pending)
- Capital: $1,000–$5,000
- James's time: 15–25 hrs/wk
- Streams: SaaS, freelance/consulting, digital products, Zuberi-recommended
- Autonomy: low-risk autonomous, big decisions → James
- Scope: any legal revenue, highest-probability paths
- Dual tracks: revenue + capability growth (equal priority)
**Reference:** conversation-handoff.md Mission section.

### Revenue Stream Research
**Idea:** Zuberi conducts structured research on highest-probability
revenue paths for AI-augmented solo operators in 2025–2026.
**Why deferred:** James wants to discuss strategy with Architect first
before handing research to Zuberi.
**Research brief (when ready):**
1. Highest-probability revenue paths given constraints
2. Revenue stream timing (weeks 1-4 vs months 2-3 vs months 4-6)
3. Skill leverage analysis (which positioning commands highest rates)
4. Market gaps (SaaS/digital product niches, 60-90 day build window)
5. Revenue math validation (how each path contributes to $350K)
**Trigger to start:** James completes strategy discussion and gives go.

---

## 8. Graduated Items

Items that have moved from HORIZON into active implementation.
Kept here as a record of Zuberi's growth.

```
2026-02-27 — CEG Online (Section 4: Ccode Headless Auth — partially graduated)
  CEG is online with Tailscale (100.100.101.1), Docker, SSH key auth,
  boot resilience hardened. Ccode headless auth still TBD.

2026-02-27 — CXDB Deployed (Section 2: CXDB Query Scoping — partially graduated)
  CXDB running on CEG at 100.100.101.1:9009/9010. Built from source.
  MCP wired into OpenClaw. Query scoping by project deferred until
  second project starts.

2026-02-27 — CAPABILITIES.md (Section 6 — partially graduated)
  RTL.md now serves as the live capability registry. Separate
  CAPABILITIES.md file deferred until mission execution begins.
```

---

## Appendix: Version History

| Version | Date | Change |
|---------|------|--------|
| 0.1.0 | 2026-02-24 | Initial — seeded from architecture discussions |
| 0.2.0 | 2026-02-24 | QMD hybrid memory search added (Section 6) |
| 0.3.0 | 2026-02-25 | Model refs updated: gpt-oss:20b → qwen3:14b, future target added |
| 0.4.0 | 2026-02-26 | Added Section 7 (Mission & Revenue): MISSION-350K.md deferred item, revenue stream research brief. Added to Section 4: ccode headless auth on CEG. Added to Section 6: CAPABILITIES.md registry. Updated n8n references to reflect CEG-as-toolbox framing. Updated AGENTS.md section references to match v0.7.0 numbering. |
| 0.5.0 | 2026-02-27 | Added: CXDB Total Memory Migration (Section 2) — plan to replace OpenClaw memory with CXDB as sole backend, bridge layer needed (compaction hook, QMD search, session injection). Updated QMD entry with future role as CXDB search layer. Graduated 3 items: CEG online, CXDB deployed, CAPABILITIES.md (all partial). |

---
# END HORIZON.md
# Add items freely. Graduate them when the time comes.
