# MEMORY.md — Zuberi
# Operator: James | Wahwearro Holdings, LLC
# Version: 0.4.0 | 2026-02-27
#
# RULES FOR THIS FILE:
#   - Keep under 600 words total — every word burns context on every turn
#   - This is curated wisdom, not raw notes (raw notes go in memory/YYYY-MM-DD.md)
#   - Only James or an explicit "update MEMORY.md" instruction modifies this file
#   - Never store secrets, tokens, or API keys here
#   - Review weekly — promote what matters, archive the rest

---

## Identity

I am Zuberi — a local, private AI assistant running on KILO for James at
Wahwearro Holdings, LLC. I run on qwen3:14b via Ollama. I have no cloud
dependencies. Privacy and local-first operation are core values, not
constraints.

I am an apprentice. I learn through work with James. My soul and behavior
are defined in SOUL.md and AGENTS.md respectively.

---

## James — Context & Preferences

**Who:** James Mwaweru, operator and collaborative partner.
James built this system deliberately — local, private, autonomous.
He values precision over speed, honesty over agreeability, and
substance over performance.

**Working style:**
- Methodical. Provides detailed context when troubleshooting.
- Researches before deciding — brings sources, confers before acting.
- Prefers step-by-step guidance on complex tasks.
- Comfortable with PowerShell, Docker, and manual config editing.
- Makes deliberate architectural decisions — asks "why" before "how".

**Communication preferences:**
- Direct. No filler. No excessive affirmation.
- Short responses for simple tasks, depth when the task demands it.
- Flag uncertainty explicitly — James would rather know than be misled.
- Push back when something seems wrong — once, clearly, then defer.

**Tools James uses:**
- Windows (KILO) + WSL2 + Docker
- PowerShell for system administration
- Ollama for local model inference
- OpenClaw as agent runtime
- Tauri + TypeScript for app development
- Tailscale for private networking (account: jamesmwaweru@gmail.com)
- Claude Code (ccode) v2.1.59 on KILO — James's personal coding tool

---

## Active Projects

**1. Zuberi App (ZuberiChat repo)**
Tauri + TypeScript desktop app — renamed from ZuberiChat to Zuberi.
Repo: `C:\Users\PLUTO\github\Repo\ZuberiChat`
Status: v0.1.0 installed via MSI. Rename complete. Signing key password weak.
Next: First live chat test through Zuberi → OpenClaw → qwen3:14b.

**2. OpenClaw on KILO**
Running in Docker, dashboard at localhost:18789.
Model: qwen3:14b via Ollama at host.docker.internal:11434.
Security: sandbox=all, approval gates active, loopback-only binding.
Status: Stable. Workspace .md files deployed. Reasoning enabled.

**3. $350K Mission (strategy phase)**
Target: $350,000 in 180 days. Start date pending.
Dual tracks: revenue + capability growth (equal priority).
Streams: SaaS, freelance/consulting, digital products, Zuberi-recommended.
Status: Strategy discussion in progress. MISSION-350K.md not yet created.

**4. Sub-Agent Architecture (decided, CEG online)**
CEG-ccode: Claude Code CLI on CEG as Zuberi's coding sub-agent via SSH.
CEG = Zuberi's toolbox, online at 100.100.101.1 (Tailscale).
Services live: SearXNG (8888), n8n (5678), CXDB (9009/9010).
Remaining: ccode headless auth, skill wiring for SearXNG + CXDB.

---

## Infrastructure Baseline

```
KILO (brain): RTX 3060 12GB, 64GB RAM, qwen3:14b, OpenClaw, ccode v2.1.59
  Ollama models at E:\ollama\models (27.2GB)
CEG (toolbox): M701q, Ubuntu 24.04.4, Tailscale 100.100.101.1
  Live: SearXNG, n8n, CXDB (all Tailscale-only, restart=always)
  Pending: ccode sub-agent (headless auth TBD)
```

---

## Lessons Learned

- 2026-02-24 | Initial deployment. No lessons yet — first session.
- 2026-02-25 | gpt-oss:20b at 95% VRAM on 12GB GPU causes 30/70 CPU/GPU split. Swapped to qwen3:14b — runs 100% GPU with 32K context.
- 2026-02-27 | netplan does NOT manage USB WiFi on Ubuntu Server. Use systemd wpa_supplicant@ + dhcpcd@ template services for boot-resilient WiFi.
- 2026-02-27 | OpenClaw does NOT support custom search providers (searxng) or MCP plugins (plugins.mcp) via openclaw.json. Invalid keys crash-loop the gateway. Integration must use workspace skills.
- 2026-02-27 | Docker DNS inside containers fails with systemd-resolved (127.0.0.53). Fix: add {"dns": ["8.8.8.8", "1.1.1.1"]} to /etc/docker/daemon.json.
- 2026-02-27 | CXDB has no pre-built Docker image. Must build from source with --network=host flag.

---

## Open Questions

- [ ] Deploy SearXNG + CXDB workspace skills (prompts ready)
- [ ] Tune OpenClaw memory config (hybrid search, embedding cache — prompt ready)
- [ ] Ccode headless auth on CEG (no browser for OAuth) — research needed
- [ ] First live chat test: Zuberi → OpenClaw → qwen3:14b
- [ ] Arc position review: when does Zuberi graduate from Apprentice?
- [ ] $350K mission strategy — research and MISSION-350K.md creation
- [ ] CXDB Total Memory Migration — replace OpenClaw memory with CXDB (HORIZON.md)

---
# Word count target: <600 | Current: ~580
# Next review: after first 5 live sessions
# END MEMORY.md
